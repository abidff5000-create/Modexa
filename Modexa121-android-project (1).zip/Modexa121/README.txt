Modexá 121 - Android project

APK banano:
1. Android Studio install koro.
2. File > Open > ei Modexa121 folder select koro. Gradle sync hote dao (internet lagbe).
3. Build > Build APK(s). Debug APK: app/build/outputs/apk/debug/app-debug.apk
4. Phone e install koro.

Kaj kore kivabe: app Discord web (discord.com/app) khole, app/src/main/assets/inject.js
page load er age inject kore. Oi script e UI panel + audio engine ache.
Naam bodlate: res/values/strings.xml ar assets/inject.js.

PC chhara APK (GitHub diye):
1. github.com e free account kholo, notun repository banao.
2. Ei folder er shob file (.github folder soho) upload koro.
3. Actions tab > "Build APK" run hole shesh e Artifacts theke Modexa121-apk download koro (zip er vitore app-debug.apk).
