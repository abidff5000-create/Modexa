(() => {
  if (window.__MX130V10_LOADED__) return;
  window.__MX130V10_LOADED__ = true;

  /* Modexá 121 - Discord Web mic processor (v10) */
  /* ================= settings ================= */
  const MAXDB = 2500;       /* slider maximum */
  const STAGE_DB = 120;     /* max dB per gain stage */
  const MAXBOOST = 1500;   /* extra boost slider max */
  const MAXOUT = 3000;     /* output gain slider max */
  const TOT = MAXDB + MAXBOOST;
  const PT_T = 0.06; /* pitch shifter window in seconds */
  const STAGES = Math.ceil(TOT / STAGE_DB) + 1; /* covers 2500 dB main gain + 1500 dB extra boost */
  const OSTAGES = Math.ceil(MAXOUT / STAGE_DB) + 1; /* output gain stages, up to 3000 dB */

  const DEF = {
    gain: 1, inputGain: 1, dist: 0, bitrate: 510000, loud: 100, clip: 40, ceil: true,
    reverb: false, revMix: 35, revDecay: 2.2,
    stereo: false, width: 18, wmix: 100, noise: 0,
    eqOn: true, eqL: 0, eqM: 0, eqH: 0, hp: 20, lp: 20000,
    mp3Vol: 80, mp3Loop: false, mp3Mix: true, mp3Shuffle: false,
    limiter: false, raw: false, ceil0: false, drive2: 0, outGain: 0, mono: false, bass: 0, presence: 0, lowmid: 0, air: 0,
    cAtk: 3, cRel: 120, cKnee: 6, boostStage: 0, monitor: false, bypass: false,
    gate: false, gateTh: -55, gateRel: 160, trem: false, tremRate: 6, tremDepth: 50, crush: 0,
    echo: false, ecTime: 280, ecFb: 35, ecMix: 30, robot: false, rmFreq: 50, rmMix: 100, pan: 0,
    mute: false, ptt: false, pttKey: 'ControlRight',
    /* animation */
    anim: true, animSpeed: 1, openAnim: 'flip', pageAnim: 'blur', stagger: true, sweep: true, logoAnim: true, scan: true, gridMove: true,
    wave: true, waveLines: 4, waveSpeed: 1, waveAmp: 50, ripple: true, hoverFx: true, tween: true, fabPulse: true,
    /* design */
    accent: '#5eead4', accent2: '#a78bfa', bgStyle: 'mesh', blur: 14, radius: 16, op: 94, fs: 13, font: 'rounded', pw: 860, dens: 1,
    fab: 48, fabLeft: false, borders: true, rainbow: false,
    /* v6 new */
    turbo: false, neon: true, shine: true, aurora: true, shake: true, orbs: true, glowNum: true,
    /* v7 new */
    spin: true, particles: true, partCount: 45, glitch: true, gtitle: true, spot: true, btnStyle: 'grad',
    /* v8 new */
    layout: 'dock', scheme: 'ocean', hud: true, vizMode: 'circle', vizSmooth: 70, vizCaps: true, sbVol: 100, sbMix: true, smooth: 20,
    /* v9 new */
    pitch: false, pitchSt: 0, pitchMix: 100, gainCap: 4000, mp3Rate: 1, customCss: '',
    /* v10 new */
    agc: false, agcTarget: -20, agcMax: 60, duck: false, duckDepth: 18, pro: true, rankHud: true
  };
  const AUDIO_KEYS = ['pitch','pitchSt','pitchMix','gainCap','smooth','sbVol','sbMix','ceil0','drive2','outGain','mono','bass','presence','lowmid','air','cAtk','cRel','cKnee','boostStage','gain','inputGain','dist','bitrate','loud','clip','ceil','limiter','reverb','revMix','revDecay','stereo','width','wmix','noise','eqOn','eqL','eqM','eqH','hp','lp','gate','gateTh','gateRel','trem','tremRate','tremDepth','crush','echo','ecTime','ecFb','ecMix','robot','rmFreq','rmMix','pan'];
  const LOOK_KEYS = ['anim','animSpeed','openAnim','pageAnim','stagger','sweep','logoAnim','scan','gridMove','wave','waveLines','waveSpeed','waveAmp','ripple','hoverFx','tween','fabPulse','accent','accent2','bgStyle','blur','radius','op','fs','font','pw','dens','fab','fabLeft','borders','rainbow','neon','shine','aurora','shake','orbs','glowNum','spin','particles','partCount','glitch','gtitle','spot','btnStyle','layout','scheme','hud','vizMode','vizSmooth','vizCaps','customCss','pro','rankHud'];
  let S = { ...DEF };
  try {
    const cur = JSON.parse(localStorage.getItem('mx130v10') || localStorage.getItem('mx130v9') || 'null');
    if (cur) Object.assign(S, cur);
    else {
      const old = JSON.parse(localStorage.getItem('mx130v8') || localStorage.getItem('mx130v7') || localStorage.getItem('mx130v6') || localStorage.getItem('mx130v5') || localStorage.getItem('mx2000') || localStorage.getItem('mx130') || '{}');
      LOOK_KEYS.forEach(k => delete old[k]);
      Object.assign(S, old);
      S.limiter = false; S.ceil0 = false; /* limiters off by default */
    }
  } catch (e) {}
  const save = () => { try { localStorage.setItem('mx130v10', JSON.stringify(S)); } catch (e) {} };

  /* ================= audio engine ================= */
  let ctx, nodes, micSrc, micStream, lastDecay = 0, gateOpen = true, pttDown = false, onMuteChange = () => {};
  const sm = (p, v) => p.setTargetAtTime(v, ctx.currentTime, Math.max(0.002, (Number(S.smooth) || 20) / 1000));
  const au = new Audio();
  au.crossOrigin = 'anonymous';

  function makeIR(decay) {
    const len = Math.max(1, Math.floor(ctx.sampleRate * decay));
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5);
    }
    return buf;
  }
  function tanhCurve(drive) {
    const n = 2048, c = new Float32Array(n), t = Math.tanh(drive);
    for (let i = 0; i < n; i++) c[i] = Math.tanh(drive * (i * 2 / n - 1)) / t;
    return c;
  }

  function ensureCtx() {
    if (ctx) return;
    ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'interactive' });
    const n = (nodes = {});
    const g = () => ctx.createGain();
    const bq = (type, f, q) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; if (q) b.Q.value = q; return b; };
    n.micProc = g(); n.micRaw = g(); n.inputGain = g(); n.input = g();
    n.gate = g(); n.anG = ctx.createAnalyser(); n.anG.fftSize = 512; n.trem = g(); n.lfo = ctx.createOscillator(); n.lfoD = g(); n.crush = ctx.createWaveShaper();
    n.lfo.frequency.value = 6; n.lfo.connect(n.lfoD); n.lfoD.connect(n.trem.gain); n.lfo.start();
    n.hp = bq('highpass', 20, 0.707); n.lp = bq('lowpass', 20000, 0.707);
    n.eqL = bq('lowshelf', 200); n.eqM = bq('peaking', 1500, 1); n.eqH = bq('highshelf', 4000);
    n.eqLM = bq('peaking', 500, 1); n.eqP = bq('peaking', 3000, 1.2); n.eqB = bq('lowshelf', 90); n.eqA = bq('highshelf', 9000);

    /* staged gain: every stage is a gain node (<= 120 dB) followed by a hard clamp to full scale.
       Because the signal is clamped between stages it can never grow past 1.0 x 10^6, so float32 never overflows,
       and the total applied gain is exactly the sum of the stages (up to 2500 dB + extra boost). */
    const clampCurve = new Float32Array([-1, 1]);
    n.stg = [];
    for (let i = 0; i < STAGES; i++) {
      const sg = g(), sc = ctx.createWaveShaper();
      sc.curve = clampCurve;
      sg.connect(sc);
      if (i) n.stg[i - 1].c.connect(sg);
      n.stg.push({ g: sg, c: sc });
    }

    /* output gain stages (up to 3000 dB), each clamped to full scale */
    n.ostg = [];
    for (let i = 0; i < OSTAGES; i++) {
      const og = g(), oc = ctx.createWaveShaper();
      oc.curve = clampCurve;
      og.connect(oc);
      if (i) n.ostg[i - 1].c.connect(og);
      n.ostg.push({ g: og, c: oc });
    }

    n.clip2 = ctx.createWaveShaper(); n.clip2.oversample = '4x'; n.outG = g();
    n.shaper = ctx.createWaveShaper(); n.shaper.oversample = '4x';
    n.revDry = g(); n.revWet = g(); n.conv = ctx.createConvolver(); n.revOut = g();
    n.stA = g(); n.stA.channelCount = 2; n.stA.channelCountMode = 'explicit';
    n.stB = g();
    n.wDelay = ctx.createDelay(0.1);
    n.wMerge = ctx.createChannelMerger(2);
    n.pre = g();
    n.comp = ctx.createDynamicsCompressor(); n.comp.knee.value = 6; n.comp.attack.value = 0.003; n.comp.release.value = 0.12;
    n.makeup = g();
    n.clip = ctx.createWaveShaper(); n.clip.oversample = '4x';
    n.lim = ctx.createDynamicsCompressor(); n.lim.knee.value = 0; n.lim.ratio.value = 20; n.lim.attack.value = 0.001; n.lim.release.value = 0.1;
    n.out = g();
    n.an = ctx.createAnalyser(); n.an.fftSize = 1024;
    n.dest = ctx.createMediaStreamDestination(); n.dest.channelCount = 2;
    n.mon = g();
    n.mp3Src = ctx.createMediaElementSource(au);
    n.mp3Vol = g(); n.mp3Send = g(); n.sbG = g(); n.sbSend = g();
    n.noiseG = g();
    n.ecDry = g(); n.ecDelay = ctx.createDelay(2); n.ecFb = g(); n.ecWet = g();
    n.rmIn = g(); n.rmDry = g(); n.rmMul = g(); n.rmWet = g(); n.rmOsc = ctx.createOscillator();
    n.rmMul.gain.value = 0; n.rmOsc.type = 'sine'; n.rmOsc.connect(n.rmMul.gain); n.rmOsc.start();
    n.pan = ctx.createStereoPanner(); n.muteG = g();
    const nb = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), nd = nb.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
    n.noiseSrc = ctx.createBufferSource(); n.noiseSrc.buffer = nb; n.noiseSrc.loop = true;
    /* pitch shifter: two crossfaded delay taps whose delay time ramps (classic dual-tap shifter) */
    n.pitIn = g(); n.pitDry = g(); n.pitWet = g(); n.pitOut = g(); n.pt = [];
    {
      const L = ctx.sampleRate, rb = ctx.createBuffer(1, L, L), wb = ctx.createBuffer(1, L, L), rd = rb.getChannelData(0), wd = wb.getChannelData(0);
      for (let i = 0; i < L; i++) { rd[i] = i / L; wd[i] = Math.pow(Math.sin(Math.PI * i / L), 2); }
      [0, 0.5].forEach(off => {
        const dl = ctx.createDelay(0.25), dg = g(), wg = g(), rs = ctx.createBufferSource(), ws = ctx.createBufferSource();
        rs.buffer = rb; ws.buffer = wb; rs.loop = true; ws.loop = true; rs.playbackRate.value = 1 / PT_T; ws.playbackRate.value = 1 / PT_T;
        wg.gain.value = 0; rs.connect(dg); dg.connect(dl.delayTime); ws.connect(wg.gain);
        n.pitIn.connect(dl); dl.connect(wg); wg.connect(n.pitWet);
        rs.start(0, off); ws.start(0, off);
        n.pt.push({ dl, dg });
      });
    }

    n.micProc.connect(n.input); n.micRaw.connect(n.out);
    n.input.connect(n.hp); n.hp.connect(n.eqL); n.eqL.connect(n.eqM); n.eqM.connect(n.eqH); n.eqH.connect(n.eqLM); n.eqLM.connect(n.eqP); n.eqP.connect(n.eqB); n.eqB.connect(n.eqA); n.eqA.connect(n.lp);
    n.lp.connect(n.anG); n.lp.connect(n.gate); n.gate.connect(n.stg[0].g);
    n.stg[STAGES - 1].c.connect(n.shaper);
    n.shaper.connect(n.revDry); n.shaper.connect(n.conv); n.conv.connect(n.revWet);
    n.revDry.connect(n.revOut); n.revWet.connect(n.revOut);
    n.revOut.connect(n.stA); n.revOut.connect(n.wMerge, 0, 0); n.revOut.connect(n.wDelay); n.wDelay.connect(n.wMerge, 0, 1);
    n.wMerge.connect(n.stB); n.stA.connect(n.trem); n.stB.connect(n.trem);
    n.trem.connect(n.ecDry); n.ecDry.connect(n.rmIn); n.trem.connect(n.ecDelay); n.ecDelay.connect(n.ecFb); n.ecFb.connect(n.ecDelay); n.ecDelay.connect(n.ecWet); n.ecWet.connect(n.rmIn);
    n.rmIn.connect(n.rmDry); n.rmDry.connect(n.pitIn); n.rmIn.connect(n.rmMul); n.rmMul.connect(n.rmWet); n.rmWet.connect(n.pitIn); n.pitIn.connect(n.pitDry); n.pitDry.connect(n.pitOut); n.pitWet.connect(n.pitOut); n.pitOut.connect(n.pre);
    n.noiseSrc.connect(n.noiseG); n.noiseG.connect(n.pre); n.noiseSrc.start();
    n.out.connect(n.ostg[0].g); n.ostg[OSTAGES - 1].c.connect(n.outG); n.outG.connect(n.pan); n.pan.connect(n.muteG); n.muteG.connect(n.dest); n.outG.connect(n.an); n.outG.connect(n.mon); n.mon.connect(ctx.destination);
    n.mp3Src.connect(n.mp3Vol); n.mp3Vol.connect(n.mp3Send); n.mp3Send.connect(n.input); n.mp3Vol.connect(ctx.destination);
    n.sbG.connect(n.sbSend); n.sbSend.connect(n.input); n.sbG.connect(ctx.destination);
    apply();
  }

  const effBoost = () => S.turbo ? MAXBOOST : (Number(S.boostStage) || 0);
  const effOut = () => S.turbo ? MAXOUT : (Number(S.outGain) || 0);
  const totalDb = () => Math.min(Number(S.gainCap) || 4000, (Number(S.gain) || 0) + effBoost());
  const stagesUsed = () => Math.max(1, Math.ceil(Math.max(0, totalDb()) / STAGE_DB));

  function apply() {
    if (nodes) {
      const n = nodes;
      n.inputGain.gain.value = Math.max(1, Math.min(500, Number(S.inputGain) || 1));

      /* distribute the total dB over the stages, 120 dB each */
      let rem = totalDb();
      n.stg.forEach((st, i) => {
        let d;
        if (i === 0) d = Math.min(rem, STAGE_DB); else d = Math.max(0, Math.min(rem, STAGE_DB));
        rem -= d;
        sm(st.g.gain, Math.pow(10, d / 20));
      });

      const td = S.trem ? Math.max(0, Math.min(100, S.tremDepth)) / 100 : 0;
      n.trem.gain.value = 1 - td / 2; n.lfoD.gain.value = td / 2; n.lfo.frequency.value = Math.max(0.1, S.tremRate);
      if (!S.gate) { n.gate.gain.cancelScheduledValues(0); n.gate.gain.value = 1; gateOpen = true; }
      if (S.crush > 0) {
        const lv = Math.pow(2, Math.max(2, 16 - S.crush)) / 2, cc = new Float32Array(4096);
        for (let i = 0; i < cc.length; i++) cc[i] = Math.round((i / 2047.5 - 1) * lv) / lv;
        n.crush.curve = cc;
      } else n.crush.curve = null;
      n.eqLM.gain.value = S.eqOn ? S.lowmid : 0; n.eqP.gain.value = S.eqOn ? S.presence : 0; n.eqB.gain.value = S.eqOn ? S.bass : 0; n.eqA.gain.value = S.eqOn ? S.air : 0;
      { const oDb = effOut(); let ro = Math.max(0, oDb);
        n.ostg.forEach(st => { const d = Math.min(ro, STAGE_DB); ro -= d; sm(st.g.gain, Math.pow(10, d / 20)); });
        n.outG.gain.value = Math.pow(10, Math.min(0, oDb) / 20); }
      n.comp.attack.value = S.cAtk / 1000; n.comp.release.value = S.cRel / 1000; n.comp.knee.value = S.cKnee;
      n.dest.channelCount = S.mono ? 1 : 2;
      n.shaper.curve = S.dist > 0 ? tanhCurve(1 + S.dist * 0.3) : null;
      const m = S.revMix / 100;
      n.revWet.gain.value = S.reverb ? m : 0;
      n.revDry.gain.value = S.reverb ? 1 - 0.5 * m : 1;
      if (S.revDecay !== lastDecay) { lastDecay = S.revDecay; n.conv.buffer = makeIR(S.revDecay); }
      n.stA.gain.value = S.stereo ? 1 - S.wmix / 100 : 1;
      n.stB.gain.value = S.stereo ? S.wmix / 100 : 0;
      n.wDelay.delayTime.value = S.width / 1000;
      n.noiseG.gain.value = S.noise / 100 * 0.25;
      n.ecDelay.delayTime.value = S.ecTime / 1000; n.ecFb.gain.value = Math.min(0.92, S.ecFb / 100);
      n.ecWet.gain.value = S.echo ? S.ecMix / 100 : 0; n.ecDry.gain.value = 1;
      n.rmOsc.frequency.value = S.rmFreq; n.rmWet.gain.value = S.robot ? S.rmMix / 100 : 0; n.rmDry.gain.value = S.robot ? 1 - S.rmMix / 100 : 1;
      n.pan.pan.value = Math.max(-1, Math.min(1, S.pan / 100));
      { const R = Math.pow(2, (Number(S.pitchSt) || 0) / 12), up = R > 1, D = Math.min(0.12, Math.abs(R - 1) * PT_T);
        const on = !!S.pitch && Math.abs(Number(S.pitchSt) || 0) > 0.01, m = on ? Math.max(0, Math.min(1, S.pitchMix / 100)) : 0;
        n.pitWet.gain.value = m; n.pitDry.gain.value = on ? 1 - m : 1;
        n.pt.forEach(t => { t.dl.delayTime.value = up ? D : 0; t.dg.gain.value = up ? -D : D; }); }
      applyMute();
      const eo = S.eqOn;
      n.eqL.gain.value = eo ? S.eqL : 0; n.eqM.gain.value = eo ? S.eqM : 0; n.eqH.gain.value = eo ? S.eqH : 0;
      n.hp.frequency.value = eo ? S.hp : 20; n.lp.frequency.value = eo ? S.lp : 20000;
      redrawEQ();
      /* loudness chain: pre -> comp -> makeup -> clipper -> limiter -> out */
      n.pre.disconnect(); n.comp.disconnect(); n.makeup.disconnect(); n.clip.disconnect(); n.clip2.disconnect(); n.crush.disconnect(); n.lim.disconnect();
      n.lim.threshold.value = S.ceil0 ? -0.05 : (S.ceil ? -0.3 : -3);
      n.clip.curve = S.clip > 0 ? tanhCurve(1 + S.clip * 0.2) : null;
      n.clip2.curve = S.drive2 > 0 ? tanhCurve(1 + S.drive2 * 0.2) : null;
      const tail = S.limiter ? n.lim : n.out;
      if (S.limiter) n.lim.connect(n.out);
      if (S.loud > 0) {
        n.comp.threshold.value = Math.max(-100, -10 - S.loud * 0.35);
        n.comp.ratio.value = Math.min(20, 4 + S.loud * 0.12);
        n.makeup.gain.value = Math.pow(10, (Math.min(S.loud, 400) * 0.3) / 20);
        n.pre.connect(n.comp); n.comp.connect(n.makeup); n.makeup.connect(n.clip);
      } else n.pre.connect(n.clip);
      n.clip.connect(n.clip2); n.clip2.connect(n.crush); n.crush.connect(tail);
      n.micProc.gain.value = S.bypass ? 0 : 1;
      n.micRaw.gain.value = S.bypass ? 1 : 0;
      n.mon.gain.value = S.monitor ? 1 : 0;
      n.mp3Vol.gain.value = S.mp3Vol / 100;
      n.mp3Send.gain.value = S.mp3Mix ? 1 : 0;
      n.sbG.gain.value = (Number(S.sbVol) || 0) / 100; n.sbSend.gain.value = S.sbMix ? 1 : 0;
    }
    au.loop = S.mp3Loop; au.playbackRate = Number(S.mp3Rate) || 1;
    applyBitrateAll();
  }

  function applyMute() {
    if (nodes) { const m = S.mute || (S.ptt && !pttDown); nodes.muteG.gain.setTargetAtTime(m ? 0 : 1, ctx.currentTime, 0.015); }
    onMuteChange();
  }

  function wrapStream(st) {
    ensureCtx();
    ctx.resume();
    if (micSrc) { try { micSrc.disconnect(); } catch (e) {} }
    if (micStream) micStream.getTracks().forEach(t => { try { t.stop(); } catch (e) {} });
    micStream = new MediaStream(st.getAudioTracks());
    micSrc = ctx.createMediaStreamSource(micStream); chk('mic');
    micSrc.connect(nodes.inputGain); nodes.inputGain.connect(nodes.micProc); nodes.inputGain.connect(nodes.micRaw);
    const track = nodes.dest.stream.getAudioTracks()[0].clone();
    return new MediaStream([track, ...st.getVideoTracks()]);
  }

  const md = navigator.mediaDevices;
  if (md && md.getUserMedia) {
    const orig = md.getUserMedia.bind(md);
    md.getUserMedia = async function (c) {
      let cc = c;
      if (c && c.audio && S.raw) {
        const a = c.audio === true ? {} : { ...c.audio };
        Object.assign(a, { echoCancellation: false, noiseSuppression: false, autoGainControl: false });
        cc = { ...c, audio: a };
      }
      const st = await orig(cc);
      if (!st.getAudioTracks().length) return st;
      try { return wrapStream(st); } catch (e) { console.warn('[Modexá 121]', e); return st; }
    };
  }

  /* ================= encoder bitrate ================= */
  const pcs = new Set();
  function applyBitrate(pc) {
    try {
      pc.getSenders().forEach(s => {
        if (s.track && s.track.kind === 'audio') {
          const p = s.getParameters();
          if (!p.encodings || !p.encodings.length) p.encodings = [{}];
          p.encodings[0].maxBitrate = S.bitrate;
          s.setParameters(p).catch(() => {});
        }
      });
    } catch (e) {}
  }
  function applyBitrateAll() {
    pcs.forEach(pc => { if (pc.connectionState === 'closed') pcs.delete(pc); else applyBitrate(pc); });
  }
  const ORig = window.RTCPeerConnection;
  if (ORig) {
    const P = function (...a) {
      const pc = new ORig(...a);
      pcs.add(pc);
      pc.addEventListener('signalingstatechange', () => applyBitrate(pc));
      pc.addEventListener('connectionstatechange', () => applyBitrate(pc));
      return pc;
    };
    P.prototype = ORig.prototype;
    Object.setPrototypeOf(P, ORig);
    window.RTCPeerConnection = P;
  }
  setInterval(applyBitrateAll, 4000);

  /* ================= UI ================= */
  const el = (t, a = {}, ...c) => {
    const e = document.createElement(t);
    for (const k in a) {
      if (k === 'class') e.className = a[k];
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), a[k]);
      else e.setAttribute(k, a[k]);
    }
    c.flat().forEach(x => { if (x != null) e.append(x.nodeType ? x : document.createTextNode(x)); });
    return e;
  };
  const NS = 'http://www.w3.org/2000/svg';
  const FONTS = {
    sans: '"Inter",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif',
    rounded: 'ui-rounded,"SF Pro Rounded","Nunito","Quicksand",system-ui,"Segoe UI",sans-serif',
    techno: '"Orbitron","Rajdhani","Segoe UI",system-ui,sans-serif',
    mono: 'ui-monospace,Menlo,Consolas,monospace',
    serif: 'Georgia,"Times New Roman",serif'
  };
  const MONO = 'ui-monospace,Menlo,Consolas,monospace';

  const CSS = `
:host{all:initial}
.wrap{display:contents;--bg:#0a0d13;--surf:#111620;--surf2:#161c28;--line:#222a3b;--text:#e7ebf4;--mute:#7c869f;--warn:#f5a524;--bad:#f0465a;--ok:#34d399;--spd:1}
*{box-sizing:border-box;font-family:var(--ff)}
.mono,.sl b,.rd,.hn,.stat b,.pill{font-family:ui-monospace,Menlo,Consolas,monospace}
.wrap.noanim *,.wrap.noanim *::before,.wrap.noanim *::after{animation:none!important;transition:none!important}

/* floating launcher */
.fab{position:fixed;bottom:96px;width:var(--fab);height:var(--fab);border-radius:calc(var(--fab)*.3);border:1px solid var(--line);background:var(--bg);display:flex;align-items:center;justify-content:center;gap:3px;padding:0;z-index:2147483647;cursor:pointer;transition:transform calc(.3s*var(--spd)) cubic-bezier(.2,1.4,.4,1),border-color .2s;box-shadow:0 12px 30px rgba(0,0,0,.55)}
.fab::before{content:"";position:absolute;left:6px;right:6px;bottom:4px;height:2px;border-radius:2px;background:linear-gradient(90deg,var(--accent) calc(var(--lvl,0)*100%),transparent 0);opacity:.95}
.fab:hover{transform:translateY(-3px);border-color:var(--accent)}
.fab:active{transform:scale(.93)}
.fab i{width:4px;border-radius:2px;background:var(--accent);height:calc(6px + var(--lvl,0)*16px*var(--k));transition:height .07s linear}
.fab.idle i{animation:idle calc(1.8s*var(--spd)) ease-in-out infinite;animation-delay:calc(var(--k)*-1.4s)}
.fab.idle:not(.nopulse)::after{content:"";position:absolute;inset:-1px;border-radius:inherit;border:1px solid var(--accent);opacity:0;animation:fabp calc(3.2s*var(--spd)) ease-out infinite}
@keyframes idle{50%{transform:scaleY(1.7)}}
@keyframes fabp{0%{opacity:.5;transform:scale(1)}100%{opacity:0;transform:scale(1.45)}}

/* panel */
.panel{position:fixed;z-index:2147483646;width:min(94vw,var(--pw));height:min(84vh,650px);color:var(--text);display:none;flex-direction:column;overflow:hidden;font-size:var(--fs);border-radius:var(--radius);border:1px solid var(--line);box-shadow:0 30px 90px rgba(0,0,0,.68)}
.panel.bg-glass{background:color-mix(in srgb,var(--bg) var(--opp),transparent);backdrop-filter:blur(calc(var(--blur)*1px));-webkit-backdrop-filter:blur(calc(var(--blur)*1px))}
.panel.bg-solid,.panel.bg-grid{background:var(--bg)}
.panel.bg-gradient{background:radial-gradient(120% 90% at 0% 0%,color-mix(in srgb,var(--accent) 17%,var(--bg)),var(--bg) 62%)}
.oa-rise{--oa:a-rise}.oa-scale{--oa:a-scale}.oa-slide{--oa:a-slide}.oa-clip{--oa:a-clip}.oa-fade{--oa:a-fade}
.panel.on{display:flex;animation-name:var(--oa,a-rise);animation-duration:calc(.5s*var(--spd));animation-timing-function:cubic-bezier(.16,1,.3,1);animation-fill-mode:both}
.panel.out{animation:a-out calc(.2s*var(--spd)) ease-in both}
@keyframes a-rise{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
@keyframes a-scale{from{opacity:0;transform:scale(.9)}to{opacity:1;transform:none}}
@keyframes a-slide{from{opacity:0;transform:translateX(-60px)}to{opacity:1;transform:none}}
@keyframes a-clip{from{clip-path:inset(0 0 100% 0 round 12px);opacity:.4}to{clip-path:inset(0 0 0 0 round 0);opacity:1}}
@keyframes a-fade{from{opacity:0}to{opacity:1}}
@keyframes a-out{to{opacity:0;transform:translateY(8px) scale(.98)}}
canvas.bg{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0}
.fx{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:0}
.fx::before{content:"";position:absolute;inset:-28px 0 0 -28px;background-image:linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px);background-size:28px 28px;animation:gridmove calc(18s*var(--spd)) linear infinite}
.panel.nogrid .fx::before{animation:none}
.panel.bg-solid .fx::before,.panel.bg-gradient .fx::before{display:none}
@keyframes gridmove{to{transform:translate(28px,28px)}}
.fx::after{content:"";position:absolute;left:0;right:0;height:140px;top:-140px;background:linear-gradient(180deg,transparent,color-mix(in srgb,var(--accent) 7%,transparent),transparent);animation:scan calc(8s*var(--spd)) ease-in-out infinite}
.panel.noscan .fx::after{display:none}
@keyframes scan{to{top:105%}}

.hd,.tabs,main,.toasts{position:relative;z-index:1}
.hd{display:flex;align-items:center;gap:12px;padding:0 10px 0 16px;height:50px;flex:none;cursor:move;touch-action:none;user-select:none;border-bottom:1px solid var(--line);background:color-mix(in srgb,var(--surf) 80%,transparent);overflow:hidden}
.hd::after{content:"";position:absolute;bottom:0;left:-40%;width:40%;height:1px;background:linear-gradient(90deg,transparent,var(--accent),transparent);animation:sweep calc(4.5s*var(--spd)) ease-in-out infinite}
.panel.nosweep .hd::after{display:none}
@keyframes sweep{to{left:100%}}
.logo{display:flex;align-items:center;gap:2px;height:20px}
.logo i{width:3px;height:100%;border-radius:2px;background:var(--accent);transform-origin:center;animation:lg calc(1.5s*var(--spd)) ease-in-out infinite}
.logo i:nth-child(1){animation-delay:-.1s;height:45%}.logo i:nth-child(2){animation-delay:-.5s;height:100%}.logo i:nth-child(3){animation-delay:-.9s;height:70%}.logo i:nth-child(4){animation-delay:-1.2s;height:35%}
.panel.nologo .logo i{animation:none}
@keyframes lg{50%{transform:scaleY(.4)}}
.ti{font-weight:700;letter-spacing:3px;font-size:1.02em}
.ver{margin-left:8px;padding:2px 7px;border-radius:4px;border:1px solid color-mix(in srgb,var(--accent) 50%,transparent);color:var(--accent);font-size:.74em;letter-spacing:1px;font-weight:600}
.st{display:flex;align-items:center;gap:8px;color:var(--mute);font-size:.86em;margin-left:auto}
.dot{width:7px;height:7px;border-radius:50%;background:#444b5d;flex:none}
.dot.live{background:var(--ok);animation:ping calc(1.8s*var(--spd)) ease-out infinite}
@keyframes ping{0%{box-shadow:0 0 0 0 rgba(52,211,153,.6)}100%{box-shadow:0 0 0 9px transparent}}
.mb{border:1px solid var(--line);background:var(--surf2);color:var(--text);border-radius:6px;padding:5px 10px;font-size:.82em;letter-spacing:1px;cursor:pointer;transition:background .2s,border-color .2s,color .2s}
.mb:hover{border-color:var(--accent)}
.mb.muted{background:var(--bad);border-color:var(--bad);color:#fff}
.x{position:relative;width:30px;height:30px;border:0;background:none;cursor:pointer;border-radius:6px;transition:background .15s,transform calc(.3s*var(--spd))}
.x:hover{background:rgba(255,255,255,.07);transform:rotate(90deg)}
.x::before,.x::after{content:"";position:absolute;left:8px;right:8px;top:14px;height:2px;border-radius:2px;background:var(--text)}
.x::before{transform:rotate(45deg)}.x::after{transform:rotate(-45deg)}

.tabs{position:relative;display:flex;gap:2px;padding:0 10px;overflow-x:auto;flex:none;border-bottom:1px solid var(--line);scrollbar-width:none;background:color-mix(in srgb,var(--surf) 55%,transparent)}
.tabs::-webkit-scrollbar{display:none}
.tabs button{position:relative;overflow:hidden;background:none;border:0;color:var(--mute);cursor:pointer;padding:12px 13px;white-space:nowrap;font-size:.96em;transition:color .2s}
.tabs button:hover{color:var(--text)}
.tabs button.act{color:var(--accent)}
.bar{position:absolute;left:0;bottom:0;height:2px;width:0;border-radius:2px 2px 0 0;background:var(--accent);box-shadow:0 0 14px var(--accent);transition:transform calc(.45s*var(--spd)) cubic-bezier(.16,1,.3,1),width calc(.45s*var(--spd)) cubic-bezier(.16,1,.3,1)}

main{flex:1;min-height:0;overflow:auto;padding:14px 16px 18px}
main::-webkit-scrollbar{width:6px}main::-webkit-scrollbar-thumb{background:#2a3144;border-radius:6px}
.in{animation-duration:calc(.5s*var(--spd));animation-timing-function:cubic-bezier(.16,1,.3,1);animation-fill-mode:both;animation-delay:calc(var(--i,0)*30ms)}
.pg-slide .in{animation-name:i-slide}.pg-fade .in{animation-name:i-fade}.pg-zoom .in{animation-name:i-zoom}.pg-none .in{animation:none}
@keyframes i-slide{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
@keyframes i-fade{from{opacity:0}to{opacity:1}}
@keyframes i-zoom{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:none}}

.card{background:color-mix(in srgb,var(--surf) 88%,transparent);border:1px solid var(--line);border-radius:calc(var(--radius)*.85);padding:calc(14px*var(--dens)) calc(16px*var(--dens));margin-bottom:calc(12px*var(--dens));transition:border-color .25s}
.card:hover{border-color:color-mix(in srgb,var(--accent) 35%,var(--line))}
.card h3{margin:0 0 calc(8px*var(--dens));font-size:.74em;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--mute);display:flex;align-items:center;gap:8px}
.card h3::before{content:"";width:3px;height:11px;border-radius:2px;background:var(--accent)}
.cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:0 12px}
.sl{margin:calc(9px*var(--dens)) 0 calc(12px*var(--dens))}
.sl .h{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:4px}
.sl b{color:var(--accent);font-weight:600;font-size:.92em}
.sl input{-webkit-appearance:none;appearance:none;display:block;width:100%;height:18px;margin:0;background:transparent;outline:0;cursor:pointer;touch-action:pan-y;--p:0%}
.sl input::-webkit-slider-runnable-track{height:4px;border-radius:4px;background:linear-gradient(90deg,var(--accent) var(--p),#232a3b var(--p))}
.sl input::-moz-range-track{height:4px;border-radius:4px;background:#232a3b}
.sl input::-moz-range-progress{height:4px;border-radius:4px;background:var(--accent)}
.sl input::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;margin-top:-5px;border-radius:50%;background:#fff;border:0;box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 45%,transparent);transition:box-shadow .2s,transform .2s}
.sl input::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:#fff;border:0;box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 45%,transparent)}
.sl input:hover::-webkit-slider-thumb{box-shadow:0 0 0 5px color-mix(in srgb,var(--accent) 40%,transparent)}
.sl input:active::-webkit-slider-thumb{transform:scale(1.2);box-shadow:0 0 0 7px color-mix(in srgb,var(--accent) 35%,transparent)}
.sl b.tick{animation:tick .25s ease-out}
@keyframes tick{from{opacity:.4;transform:translateY(-3px)}to{opacity:1;transform:none}}

.tg{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:calc(8px*var(--dens)) 0;cursor:pointer;border-bottom:1px solid var(--line);transition:padding .2s}
.tg:last-child{border-bottom:0}
.tg:hover{padding-left:5px}
.nohover .tg:hover{padding-left:0}
.tg input{-webkit-appearance:none;appearance:none;position:relative;flex:none;width:36px;height:20px;margin:0;border-radius:20px;background:#252c3d;cursor:pointer;transition:background .25s}
.tg input::after{content:"";position:absolute;top:3px;left:3px;width:14px;height:14px;border-radius:50%;background:#98a1b8;transition:transform calc(.3s*var(--spd)) cubic-bezier(.3,1.5,.5,1),background .2s}
.tg input:checked{background:color-mix(in srgb,var(--accent) 38%,#252c3d)}
.tg input:checked::after{transform:translateX(16px);background:var(--accent)}
.sel{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:6px 0}
.sel select{background:var(--surf2);color:var(--text);border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-size:.95em;outline:0;cursor:pointer}
.sel select:focus{border-color:var(--accent)}

.btn{position:relative;overflow:hidden;background:var(--surf2);color:var(--text);border:1px solid var(--line);padding:7px 13px;cursor:pointer;margin:4px 6px 4px 0;border-radius:calc(var(--radius)*.55);font-size:.95em;transition:border-color .2s,transform .15s,background .2s,color .2s}
.btn:hover{border-color:var(--accent);transform:translateY(-1px)}
.nohover .btn:hover{transform:none}
.btn:active{transform:scale(.96)}
.btn.pri{background:var(--accent);border-color:var(--accent);color:#04101a;font-weight:600}
.btn.dn{border-color:color-mix(in srgb,var(--bad) 55%,var(--line))}
.rip{position:absolute;width:12px;height:12px;margin:-6px 0 0 -6px;border-radius:50%;background:var(--accent);opacity:.35;transform:scale(0);animation:rip .6s ease-out forwards;pointer-events:none}
@keyframes rip{to{transform:scale(24);opacity:0}}
.sw{display:inline-block;width:42px;height:42px;margin:4px 8px 4px 0;cursor:pointer;border-radius:10px;border:2px solid transparent;transition:transform calc(.25s*var(--spd)) cubic-bezier(.3,1.6,.5,1),border-color .2s}
.sw:hover{transform:scale(1.1)}.sw.act{border-color:#fff}
.row{display:flex;align-items:center;gap:10px;margin:7px 0}
.row input[type=color]{width:46px;height:28px;border:1px solid var(--line);background:none;padding:0;border-radius:6px;cursor:pointer}
.q{display:flex;flex-wrap:wrap}

/* gain hero */
.hero{display:flex;align-items:center;gap:20px;flex-wrap:wrap}
.dialwrap{position:relative;width:150px;height:150px;flex:none}
.dial{width:100%;height:100%}
.dtrack,.darc{fill:none;stroke-width:9;stroke-linecap:round}
.dtrack{stroke:#202738}
.darc{stroke:var(--accent);transition:stroke-dasharray calc(.7s*var(--spd)) cubic-bezier(.16,1,.3,1),stroke .4s;filter:drop-shadow(0 0 6px color-mix(in srgb,var(--accent) 55%,transparent))}
.hero.mid .darc{stroke:var(--warn)}.hero.max .darc{stroke:var(--bad)}
.dc{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.hn{font-size:1.9em;font-weight:700;color:var(--text);font-variant-numeric:tabular-nums;line-height:1}
.dc small{color:var(--mute);margin-top:3px;letter-spacing:2px;font-size:.8em}
.hside{flex:1;min-width:210px}
.ht{font-size:.7em;letter-spacing:2.4px;color:var(--mute);font-weight:700}
.hs{color:var(--text);margin:3px 0 10px}
.cells{display:flex;gap:3px;height:8px;margin-bottom:10px}
.cell{position:relative;flex:1;border-radius:2px;background:#202738;overflow:hidden}
.cell i{position:absolute;inset:0;background:linear-gradient(90deg,var(--accent2),var(--accent));transform-origin:left;transform:scaleX(0);transition:transform calc(.6s*var(--spd)) cubic-bezier(.16,1,.3,1)}
.hero.mid .cell i{background:var(--warn)}.hero.max .cell i{background:var(--bad)}

.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px}
.stat{background:color-mix(in srgb,var(--surf) 88%,transparent);border:1px solid var(--line);border-radius:calc(var(--radius)*.7);padding:10px 12px}
.stat span{display:block;font-size:.68em;letter-spacing:1.8px;color:var(--mute);text-transform:uppercase}
.stat b{display:block;margin-top:3px;font-size:1.15em;font-weight:600;font-variant-numeric:tabular-nums}
.meter{position:relative;height:12px;border-radius:3px;overflow:hidden;background:linear-gradient(90deg,var(--accent) 0%,var(--accent) 62%,var(--warn) 82%,var(--bad) 100%);-webkit-mask-image:repeating-linear-gradient(90deg,#000 0 5px,transparent 5px 7px);mask-image:repeating-linear-gradient(90deg,#000 0 5px,transparent 5px 7px)}
.meter i{position:absolute;top:0;right:0;bottom:0;width:100%;background:#151a25;transition:width .07s linear}
.meter u{position:absolute;top:0;bottom:0;width:3px;background:#fff;left:0;transition:left .09s linear}
.rd{color:var(--mute);font-size:.88em;margin:8px 0 2px}
.note{color:var(--mute);line-height:1.6;margin:6px 0}
.cv{width:100%;background:#090c12;border:1px solid var(--line);border-radius:6px;display:block}
.pill{margin-left:8px;padding:1px 8px;border-radius:4px;font-size:.9em;letter-spacing:1px;background:#202738;color:#5d667c;transition:background .2s,color .2s}
.pill.on{background:var(--bad);color:#fff;animation:blink .3s ease-in-out infinite alternate}
.pill.g.on{background:var(--accent);color:#04101a;animation:none}
@keyframes blink{to{opacity:.55}}
.ta{width:100%;height:88px;resize:vertical;background:#090c12;color:var(--text);border:1px solid var(--line);border-radius:6px;padding:8px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.85em;outline:0}
.ta:focus{border-color:var(--accent)}
.pl{max-height:150px;overflow:auto;border:1px solid var(--line);border-radius:6px;margin:6px 0}
.pl div{padding:7px 10px;cursor:pointer;border-bottom:1px solid var(--line);color:var(--mute);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:background .15s,color .15s}
.pl div:last-child{border-bottom:0}.pl div:hover{background:var(--surf2);color:var(--text)}.pl div.cur{color:var(--accent);background:color-mix(in srgb,var(--accent) 9%,transparent)}
.slot{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid var(--line)}
.slot:last-child{border-bottom:0}.slot span{flex:1;color:var(--mute)}.slot span.f{color:var(--text)}
.kbd{display:inline-block;padding:1px 7px;border:1px solid var(--line);border-bottom-width:2px;border-radius:4px;background:var(--surf2);font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.88em;color:var(--text)}

.toasts{position:absolute;left:0;right:0;bottom:14px;display:flex;flex-direction:column;align-items:center;gap:6px;pointer-events:none;z-index:5}
.toast{padding:9px 16px;border-radius:8px;background:#121722;border:1px solid var(--line);border-left:3px solid var(--accent);color:var(--text);font-size:.92em;box-shadow:0 12px 30px rgba(0,0,0,.6);animation:tin calc(.4s*var(--spd)) cubic-bezier(.16,1,.3,1) both}
.toast.bye{animation:tout calc(.25s*var(--spd)) ease-in both}
@keyframes tin{from{opacity:0;transform:translateY(14px)}}
@keyframes tout{to{opacity:0;transform:translateY(8px)}}

/* ===== v6 look + new animations ===== */
.btn{position:relative;overflow:hidden}
.panel{border-color:color-mix(in srgb,var(--accent) 40%,var(--line))}
.ring{position:absolute;inset:0;border-radius:inherit;pointer-events:none;z-index:6;display:none}
.panel.x-neon .ring{display:block;border:1px solid var(--accent);animation:ringg calc(3.2s*var(--spd)) ease-in-out infinite}
@keyframes ringg{0%,100%{box-shadow:inset 0 0 12px color-mix(in srgb,var(--accent) 25%,transparent)}50%{box-shadow:inset 0 0 36px color-mix(in srgb,var(--accent) 60%,transparent),inset 0 0 70px color-mix(in srgb,var(--accent2) 25%,transparent)}}
.panel.x-shine .btn::after{content:"";position:absolute;top:0;left:-70%;width:45%;height:100%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.28),transparent);transform:skewX(-20deg);animation:shine calc(3.6s*var(--spd)) ease-in-out infinite;pointer-events:none}
.panel.x-shine .btn:nth-child(even)::after{animation-delay:1.2s}
@keyframes shine{0%{left:-70%}55%,100%{left:140%}}
.panel.x-aurora .hero{background:linear-gradient(115deg,transparent 0%,color-mix(in srgb,var(--accent) 14%,transparent) 35%,color-mix(in srgb,var(--accent2) 14%,transparent) 65%,transparent 100%);background-size:250% 100%;border-radius:var(--radius);animation:aur calc(7s*var(--spd)) ease-in-out infinite alternate}
@keyframes aur{from{background-position:0 0}to{background-position:100% 0}}
.panel.x-glowNum .hn{text-shadow:0 0 18px color-mix(in srgb,var(--accent) 70%,transparent),0 0 40px color-mix(in srgb,var(--accent) 35%,transparent)}
.panel.x-shake .hero.max .hn{animation:shk .28s linear infinite}
@keyframes shk{0%,100%{transform:translate(0)}25%{transform:translate(-1.5px,1px)}50%{transform:translate(1.5px,-1px)}75%{transform:translate(-1px,-1px)}}
.panel.x-orbs .orb{position:absolute;border-radius:50%;filter:blur(38px);opacity:.28;pointer-events:none;z-index:0}
.panel.x-orbs .orb.o1{width:190px;height:190px;background:var(--accent);top:-50px;right:-40px;animation:orb1 calc(11s*var(--spd)) ease-in-out infinite alternate}
.panel.x-orbs .orb.o2{width:220px;height:220px;background:var(--accent2);bottom:-70px;left:-50px;animation:orb2 calc(14s*var(--spd)) ease-in-out infinite alternate}
.panel:not(.x-orbs) .orb{display:none}
@keyframes orb1{to{transform:translate(-120px,160px) scale(1.25)}}
@keyframes orb2{to{transform:translate(180px,-120px) scale(1.2)}}
.card{backdrop-filter:blur(6px)}

/* ===== v7: new open / page animations ===== */
.oa-flip{--oa:a-flip}.oa-bounce{--oa:a-bounce}.oa-zoomblur{--oa:a-zoomblur}.oa-swing{--oa:a-swing}
@keyframes a-flip{from{opacity:0;transform:perspective(900px) rotateX(-70deg) translateY(30px)}to{opacity:1;transform:none}}
@keyframes a-bounce{0%{opacity:0;transform:scale(.6) translateY(60px)}55%{opacity:1;transform:scale(1.04) translateY(-8px)}75%{transform:scale(.98) translateY(3px)}100%{transform:none}}
@keyframes a-zoomblur{from{opacity:0;transform:scale(1.25);filter:blur(16px)}to{opacity:1;transform:none;filter:blur(0)}}
@keyframes a-swing{from{opacity:0;transform:perspective(900px) rotateY(60deg) translateX(40px)}to{opacity:1;transform:none}}
.pg-flip .in{animation-name:i-flip}.pg-blur .in{animation-name:i-blur}.pg-bounce .in{animation-name:i-bounce}
@keyframes i-flip{from{opacity:0;transform:perspective(700px) rotateX(-25deg) translateY(10px)}to{opacity:1;transform:none}}
@keyframes i-blur{from{opacity:0;filter:blur(10px);transform:translateY(8px)}to{opacity:1;filter:blur(0);transform:none}}
@keyframes i-bounce{0%{opacity:0;transform:translateY(24px)}60%{opacity:1;transform:translateY(-5px)}100%{transform:none}}

/* ===== v7: new backgrounds ===== */
.panel.bg-mesh,.panel.bg-dots{background:var(--bg)}
.panel.bg-mesh .fx::before,.panel.bg-dots .fx::before{display:none}
.panel.bg-mesh .fx{background:radial-gradient(60% 50% at 15% 20%,color-mix(in srgb,var(--accent) 28%,transparent),transparent 70%),radial-gradient(55% 55% at 85% 25%,color-mix(in srgb,var(--accent2) 28%,transparent),transparent 70%),radial-gradient(60% 60% at 50% 100%,color-mix(in srgb,var(--accent) 18%,transparent),transparent 70%);background-size:170% 170%;animation:meshmove calc(16s*var(--spd)) ease-in-out infinite alternate}
@keyframes meshmove{from{background-position:0% 0%,100% 0%,50% 100%}to{background-position:100% 100%,0% 100%,50% 0%}}
.panel.bg-dots .fx{background-image:radial-gradient(color-mix(in srgb,var(--accent) 38%,transparent) 1px,transparent 1.5px);background-size:18px 18px;animation:dotmove calc(10s*var(--spd)) linear infinite}
@keyframes dotmove{to{background-position:18px 18px}}

/* ===== v7: spinning light border ===== */
.ring2{position:absolute;inset:0;border-radius:inherit;pointer-events:none;z-index:7;display:none;padding:2px;overflow:hidden;-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude}
.ring2::before{content:"";position:absolute;left:50%;top:50%;width:1400px;height:1400px;margin:-700px 0 0 -700px;background:conic-gradient(from 0deg,transparent 0 50%,var(--accent) 72%,var(--accent2) 88%,transparent 100%);animation:rot calc(5s*var(--spd)) linear infinite}
.panel.x-spin .ring2{display:block}
@keyframes rot{to{transform:rotate(360deg)}}

/* ===== v7: title effects ===== */
.ti{position:relative}
.panel.x-gtitle .ti{background:linear-gradient(90deg,var(--accent),var(--accent2),var(--accent));background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:tish calc(5s*var(--spd)) linear infinite}
@keyframes tish{to{background-position:200% 0}}
.panel.x-glitch .ti::after{content:attr(data-t);position:absolute;left:0;top:0;color:var(--accent2);opacity:0;pointer-events:none;animation:glt calc(4s*var(--spd)) steps(1) infinite}
@keyframes glt{0%,91%,100%{opacity:0;transform:none}92%{opacity:.95;transform:translate(-2px,1px);clip-path:inset(10% 0 55% 0)}94%{opacity:.95;transform:translate(2px,-1px);clip-path:inset(55% 0 10% 0)}96%{opacity:.95;transform:translate(-1px,0);clip-path:inset(30% 0 30% 0)}98%{opacity:0}}

/* ===== v7: card spotlight + buttons ===== */
.card{position:relative}
.panel.x-spot .card::before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:radial-gradient(260px circle at var(--mx,50%) var(--my,50%),color-mix(in srgb,var(--accent) 17%,transparent),transparent 62%);opacity:0;transition:opacity .3s}
.panel.x-spot .card:hover::before{opacity:1}
.panel.bs-grad .btn.pri{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:transparent;color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.45)}
.panel.bs-grad .btn:not(.pri):hover{background:color-mix(in srgb,var(--accent) 14%,var(--surf2))}
.panel.bs-pill .btn{border-radius:999px;padding:7px 16px}
.panel.bs-grad .btn{border-radius:999px}
.panel.x-neon .fab,.wrap .fab{box-shadow:0 0 22px color-mix(in srgb,var(--accent) 45%,transparent),0 12px 30px rgba(0,0,0,.55)}
.tabs button.act{text-shadow:0 0 14px color-mix(in srgb,var(--accent) 70%,transparent)}
.tabs button:hover{transform:translateY(-1px)}
canvas.pc{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0}

/* ===== v8: layout, sidebar, HUD, onboarding, palette, soundboard ===== */
.body{position:relative;z-index:1;flex:1;min-height:0;display:flex;flex-direction:column}
.body main{flex:1;min-height:0;min-width:0}
.tabs button .ic{display:inline-block;width:1.3em;text-align:center;opacity:.85;margin-right:5px}
.panel.lay-side .body{flex-direction:row}
.panel.lay-side .tabs{flex-direction:column;flex:none;width:162px;padding:10px 8px;overflow-x:hidden;overflow-y:auto;border-bottom:0;border-right:1px solid var(--line);gap:3px}
.panel.lay-side .tabs button{text-align:left;padding:9px 12px;border-radius:10px;display:flex;align-items:center}
.panel.lay-side .tabs button.act{background:color-mix(in srgb,var(--accent) 15%,transparent);box-shadow:inset 3px 0 0 var(--accent)}
.panel.lay-side .tabs button:hover{background:color-mix(in srgb,var(--accent) 8%,transparent)}
.panel.lay-side .bar{display:none}
@media(max-width:620px){.panel.lay-side .tabs{width:54px}.panel.lay-side .tabs button .tl{display:none}.panel.lay-side .tabs button{justify-content:center}.tabs button .ic{margin:0}}
.hud{position:fixed;bottom:calc(96px + var(--fab) + 10px);z-index:2147483645;display:none;min-width:140px;padding:8px 12px;border-radius:12px;border:1px solid color-mix(in srgb,var(--accent) 40%,var(--line));background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(10px);font:600 11px/1.4 ui-monospace,Menlo,Consolas,monospace;color:var(--text);box-shadow:0 10px 26px rgba(0,0,0,.5);pointer-events:none}
.hud.on{display:block;animation:a-fade .3s both}
.hud i{display:block;height:3px;border-radius:3px;margin-top:6px;background:linear-gradient(90deg,var(--accent2),var(--accent));width:calc(var(--lvl,0)*100%);transition:width .08s linear}
.hud em{font-style:normal;color:var(--accent)}
.ob{position:absolute;inset:0;z-index:30;display:flex;align-items:center;justify-content:center;padding:16px;background:color-mix(in srgb,var(--bg) 80%,transparent);backdrop-filter:blur(10px);animation:a-fade .4s both}
.obc{width:min(540px,100%);max-height:100%;overflow:auto;background:var(--surf);border:1px solid color-mix(in srgb,var(--accent) 45%,var(--line));border-radius:calc(var(--radius)*1.2);padding:24px 24px 18px;box-shadow:0 30px 80px rgba(0,0,0,.6),0 0 60px color-mix(in srgb,var(--accent) 18%,transparent);animation:a-rise .5s cubic-bezier(.16,1,.3,1) both}
.obh{font-size:1.55em;font-weight:800;margin:0 0 6px;background:linear-gradient(90deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent}
.obp{color:var(--mute);line-height:1.65;margin:6px 0 10px}
.obdots{display:flex;gap:6px;margin:16px 0 2px}
.obdots i{width:20px;height:4px;border-radius:4px;background:#2a3144;transition:background .3s,width .3s}
.obdots i.on{background:var(--accent);width:38px}
.obf{display:flex;justify-content:space-between;align-items:center;margin-top:14px;gap:8px}
.opt{display:block;width:100%;text-align:left;padding:11px 14px;margin:7px 0;border-radius:12px;border:1px solid var(--line);background:var(--surf2);color:var(--text);cursor:pointer;font-size:1em;transition:border-color .2s,background .2s,transform .15s}
.opt:hover{transform:translateX(3px);border-color:var(--accent)}
.opt.sel{border-color:var(--accent);background:color-mix(in srgb,var(--accent) 14%,var(--surf2))}
.opt b{display:block}.opt small{color:var(--mute)}
.obk{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}
.pal{position:absolute;inset:0;z-index:40;display:flex;align-items:flex-start;justify-content:center;padding-top:64px;background:color-mix(in srgb,var(--bg) 62%,transparent);backdrop-filter:blur(6px);animation:a-fade .2s both}
.palc{width:min(470px,92%);background:var(--surf);border:1px solid var(--accent);border-radius:14px;box-shadow:0 24px 60px rgba(0,0,0,.6),0 0 40px color-mix(in srgb,var(--accent) 20%,transparent);overflow:hidden}
.palc input{width:100%;padding:14px 16px;background:transparent;border:0;border-bottom:1px solid var(--line);color:var(--text);font-size:1.05em;outline:0}
.pall{max-height:300px;overflow:auto}
.pall div{padding:10px 16px;cursor:pointer;color:var(--mute)}
.pall div.sel,.pall div:hover{background:color-mix(in srgb,var(--accent) 15%,transparent);color:var(--text)}
.pads{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
@media(max-width:620px){.pads{grid-template-columns:repeat(2,1fr)}}
.padw{position:relative}
.pad{width:100%;height:92px;border-radius:calc(var(--radius)*.8);border:1px dashed var(--line);background:var(--surf2);color:var(--mute);cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:6px;overflow:hidden;transition:transform .15s,border-color .2s,box-shadow .2s}
.pad b{max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text);font-size:.95em}
.pad small{font-size:.75em;opacity:.8}
.pad.has{border-style:solid;border-color:color-mix(in srgb,var(--accent) 55%,var(--line));background:color-mix(in srgb,var(--accent) 8%,var(--surf2))}
.pad:hover{transform:translateY(-2px);border-color:var(--accent)}
.pad.hit{animation:padhit .4s ease-out}
@keyframes padhit{0%{transform:scale(.94);box-shadow:0 0 0 0 color-mix(in srgb,var(--accent) 60%,transparent)}100%{transform:none;box-shadow:0 0 0 18px transparent}}
.padx{position:absolute;top:5px;right:5px;width:22px;height:22px;border-radius:6px;border:1px solid var(--line);background:var(--surf);color:var(--text);cursor:pointer;line-height:1;padding:0}
.padx:hover{border-color:var(--accent)}
/* ===== v9: dock layout, confetti ===== */
.panel.lay-dock .body{flex-direction:column-reverse}
.panel.lay-dock .tabs{justify-content:center;border-bottom:0;border-top:1px solid var(--line);gap:6px;padding:8px 10px}
.panel.lay-dock .tabs button{padding:9px 12px;border-radius:14px;display:flex;align-items:center;transition:transform .25s cubic-bezier(.3,1.6,.5,1),background .2s,color .2s}
.panel.lay-dock .tabs button:not(.act) .tl{display:none}
.panel.lay-dock .tabs button:not(.act) .ic{margin:0;font-size:1.25em}
.panel.lay-dock .tabs button:hover{transform:translateY(-5px) scale(1.18)}
.panel.lay-dock .tabs button.act{background:color-mix(in srgb,var(--accent) 16%,transparent)}
.panel.lay-dock .bar{display:none}
.cf{position:absolute;top:-14px;width:8px;height:13px;z-index:60;pointer-events:none;border-radius:2px;animation:cfall 1.9s ease-in forwards}
@keyframes cfall{to{transform:translate(var(--dx,0),640px) rotate(720deg);opacity:0}}
.ob .obh{animation:a-rise .6s cubic-bezier(.16,1,.3,1) both}
.card:hover{transform:translateY(-2px);box-shadow:0 10px 28px color-mix(in srgb,var(--accent) 14%,transparent)}
@media(prefers-reduced-motion:reduce){.wrap *,.wrap *::before,.wrap *::after{animation:none!important;transition:none!important}}
@media(max-width:620px){.stats{grid-template-columns:repeat(2,1fr)}main{padding:12px}}
`;

  const CSS10 = `
/* ===== v10: pro look, rank, studio ===== */
.panel.v10{box-shadow:0 0 0 1px color-mix(in srgb,var(--accent) 35%,transparent),0 0 60px -12px color-mix(in srgb,var(--accent) 45%,transparent),0 30px 90px rgba(0,0,0,.6)}
.panel.v10 .hd{background:linear-gradient(90deg,color-mix(in srgb,var(--accent) 14%,var(--surf)),color-mix(in srgb,var(--accent2) 10%,var(--surf)))}
.panel.v10 .card{border-radius:18px;background:linear-gradient(160deg,color-mix(in srgb,var(--surf2) 80%,transparent),color-mix(in srgb,var(--surf) 90%,transparent));box-shadow:inset 0 1px 0 rgba(255,255,255,.05),0 10px 28px -16px rgba(0,0,0,.7)}
.panel.v10 .card:hover{border-color:color-mix(in srgb,var(--accent) 60%,var(--line));box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 0 28px -10px var(--accent)}
.panel.v10 .card h3{background:linear-gradient(90deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent}
.panel.v10 .btn.pri{box-shadow:0 0 22px -6px var(--accent)}
.panel.v10 .opt.sel{box-shadow:0 0 0 1px var(--accent),0 0 24px -8px var(--accent)}
.rk{margin-left:8px;padding:2px 9px;border-radius:999px;font-size:.7em;font-weight:800;letter-spacing:1.5px;cursor:pointer;color:#06121c;background:linear-gradient(90deg,var(--accent),var(--accent2));white-space:nowrap}
.rk.gt{color:#2b1700;background:linear-gradient(90deg,#ffd54a,#ff9f1c,#ffd54a);background-size:200% 100%;animation:gshine 2.2s linear infinite;box-shadow:0 0 18px #ffb300aa}
@keyframes gshine{to{background-position:-200% 0}}
.panel.goated{border-color:#ffc83a}
.prog{height:9px;border-radius:99px;background:var(--surf2);overflow:hidden;margin:8px 0}
.prog i{display:block;height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,var(--accent),var(--accent2));transition:width .25s ease}
.rkc{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap}
.rkn{font-size:1.9em;font-weight:800;letter-spacing:2px;background:linear-gradient(90deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent}
.panel.goated .rkn{background:linear-gradient(90deg,#ffd54a,#ff9f1c);-webkit-background-clip:text;background-clip:text}
.rks{color:var(--mute);font-size:.9em}
.chip{display:inline-block;padding:5px 11px;border-radius:999px;border:1px solid color-mix(in srgb,var(--accent) 45%,var(--line));background:color-mix(in srgb,var(--accent) 10%,transparent);font-size:.9em}
.score{display:flex;align-items:baseline;gap:6px;margin:6px 0}
.score b{font-size:3em;line-height:1;background:linear-gradient(90deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent}
.calr{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px dashed var(--line)}
.btn:disabled{opacity:.5;cursor:default}
`;
  const wrap = el('div', { class: 'wrap' });
  const host = el('div');
  const root = host.attachShadow({ mode: 'open' });
  const panel = el('div', { class: 'panel' });
  const canvas = el('canvas', { class: 'bg' });
  const pcanvas = el('canvas', { class: 'pc' });
  let pRunning = false; const parts = [];
  const pads = Array.from({ length: 8 }, () => ({ name: '', buf: null, src: null }));
  let vizCv = null, padEls = [], obEl = null, palEl = null, vRun = false, vData = null, vTime = null, rec = null;
  const vBars = new Float32Array(64), vCaps = new Float32Array(64);
  const SCHEMES = { void: ['#05040a', '#0b0915', '#120e22', '#241b45'], aurora: ['#06141a', '#0a1f27', '#0f2d38', '#1a4756'], obsidian: ['#07070b', '#0e0e15', '#15151f', '#26263a'], goldnoir: ['#0b0907', '#15120d', '#1e1a12', '#3a3220'], midnight: ['#0a0d13', '#111620', '#161c28', '#222a3b'], amoled: ['#000000', '#07090d', '#0d1117', '#1a2030'], slate: ['#12161f', '#1a2030', '#212840', '#2c3550'], plum: ['#0f0a18', '#181026', '#20163a', '#2f2250'], forest: ['#06100d', '#0c1a15', '#11261e', '#1c3a2e'], ocean: ['#06121c', '#0b1d2c', '#10283c', '#1b3d57'], crimson: ['#14080b', '#1f0d12', '#2b1219', '#43202a'] };
  const ICONS = { Dashboard: '◉', Studio: '⚡', Effects: '✦', 'Voice FX': '☊', Equalizer: '≋', Dynamics: '◧', Media: '♫', Soundboard: '▦', Visualizer: '◬', Presets: '★', Controls: '⌨', Animation: '✧', Design: '◐', About: 'ⓘ' };
  const main = el('main');
  const tabs = el('div', { class: 'tabs' });
  const bar = el('i', { class: 'bar' });
  let panelOpen = false, current = 'Dashboard', meterEl = null, peakEl = null, dbEl = null, gainInfo = null, eqCv = null, rvCv = null, peakHold = -120, trackName = '', buf = null, hue = 0, level = 0;
  let heroEl = null, cellsEl = null, heroNum = null, heroShown = 0, heroTok = 0, specCv = null, clipEl = null, clipT = 0, gateEl = null, histCv = null, dialArc = null, statEls = null, listEl = null;
  let list = [], idx = -1;
  const stats = { peak: -120, clips: 0, t0: Date.now(), wasClip: false };
  const hist = new Float32Array(180).fill(-60);
  const ARC = 0.75 * 2 * Math.PI * 58, CIRC = 2 * Math.PI * 58;

  const curAccent = () => (wrap.style.getPropertyValue('--accent') || S.accent).trim();
  const fmtT = s => isFinite(s) ? Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0') : '0:00';

  function mkSlider(label, min, max, step, get, set, fmt) {
    const inp = el('input', { type: 'range', min, max, step });
    inp.value = get();
    const b = el('b', {}, fmt(+inp.value));
    const paint = () => inp.style.setProperty('--p', ((inp.value - min) / (max - min) * 100) + '%');
    paint();
    inp.addEventListener('input', () => { set(+inp.value); b.textContent = fmt(+inp.value); paint(); if (S.tween) { b.classList.remove('tick'); void b.offsetWidth; b.classList.add('tick'); } });
    return el('div', { class: 'sl' }, el('div', { class: 'h' }, el('span', {}, label), b), inp);
  }
  const slider = (label, key, min, max, step, fmt, after) =>
    mkSlider(label, min, max, step, () => S[key], v => { S[key] = v; apply(); save(); after && after(); }, fmt);
  const toggle = (label, key, after) => {
    const i = el('input', { type: 'checkbox' });
    i.checked = !!S[key];
    i.addEventListener('change', () => { S[key] = i.checked; apply(); save(); after && after(); });
    return el('label', { class: 'tg' }, el('span', {}, label), i);
  };
  const select = (label, key, opts, after) => {
    const s = el('select');
    opts.forEach(([v, t]) => s.append(el('option', { value: v }, t)));
    s.value = S[key];
    s.addEventListener('change', () => { S[key] = s.value; save(); after && after(); });
    return el('label', { class: 'sel' }, el('span', {}, label), s);
  };
  const grp = (t, ...k) => el('section', { class: 'card' }, t ? el('h3', {}, t) : null, ...k);
  const cols = (...k) => el('div', { class: 'cols' }, ...k);
  const note = t => el('div', { class: 'note' }, t);
  const num = d => v => v.toFixed(d);
  const pct = v => v + '%';
  const colorRow = (label, key) => {
    const i = el('input', { type: 'color' });
    i.value = S[key];
    i.addEventListener('input', () => { S[key] = i.value; save(); applyTheme(); });
    return el('div', { class: 'row' }, i, el('span', {}, label));
  };
  const btn = (t, fn, cls) => el('button', { class: 'btn' + (cls ? ' ' + cls : ''), onclick: fn }, t);

  function tweenHero(target) {
    const from = heroShown, t0 = performance.now(), tok = ++heroTok;
    if (!S.anim || !S.tween) { heroShown = target; if (heroNum) heroNum.textContent = target.toFixed(1); return; }
    const step = now => {
      if (tok !== heroTok) return;
      const k = Math.min(1, (now - t0) / 700), e = 1 - Math.pow(1 - k, 4);
      heroShown = from + (target - from) * e;
      if (heroNum && heroNum.isConnected) heroNum.textContent = heroShown.toFixed(1);
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  const updGain = () => {
    if (!gainInfo || !gainInfo.isConnected) return;
    const t = totalDb(), u = stagesUsed();
    gainInfo.textContent = u + ' of ' + STAGES + ' gain stages active';
    heroEl.classList.toggle('mid', t > TOT * 0.4 && t <= TOT * 0.75);
    heroEl.classList.toggle('max', t > TOT * 0.75);
    dialArc.style.strokeDasharray = (Math.max(0, Math.min(1, t / TOT)) * ARC) + ' ' + CIRC;
    [...cellsEl.children].forEach((c, i) => {
      const f = Math.max(0, Math.min(1, (t - i * STAGE_DB) / STAGE_DB));
      c.firstChild.style.transform = 'scaleX(' + f + ')';
    });
    tweenHero(t);
  };

  const toastBox = el('div', { class: 'toasts' });
  function toast(msg) {
    const t = el('div', { class: 'toast' }, msg);
    toastBox.append(t);
    setTimeout(() => { t.classList.add('bye'); setTimeout(() => t.remove(), 300); }, 1700);
  }

  const THEMES = [
    ['Azure', '#4cc9f0', '#3a86ff'], ['Mint', '#3df5c4', '#1fb893'], ['Ember', '#ff7a45', '#d9480f'],
    ['Violet', '#a78bfa', '#6d28d9'], ['Lime', '#b6f23d', '#65a30d'], ['Rose', '#ff6b9a', '#be185d'],
    ['Gold', '#ffc233', '#d97706'], ['Crimson', '#ff4d5e', '#9f1239'], ['Teal', '#2dd4bf', '#0f766e'], ['Graphite', '#e6e8ee', '#8b90a0'],
    ['Orchid', '#b388ff', '#00e5ff'], ['Matrix', '#00ff6a', '#00552b'], ['Lava', '#ff5a1f', '#ffd000'], ['Cyber', '#00f0ff', '#ff2bd6'], ['Sunset', '#ff9966', '#ff5e62'], ['Ocean', '#00c6ff', '#0072ff'],
    ['Toxic', '#39ff14', '#0b8a00'], ['Sakura', '#ffb7d5', '#c04a8a'], ['Ice', '#a5f3fc', '#38bdf8'],
    ['Goated', '#ffd54a', '#ff6a00'], ['Aurora', '#7cffcb', '#74a9ff'], ['Neon Noir', '#ff2e97', '#7b2fff'], ['Glacier', '#9be7ff', '#c4b5fd']
  ];

  const RESET = { pitch: false, gain: 1, dist: 0, loud: 100, clip: 40, drive2: 0, boostStage: 0, outGain: 0, ceil0: false, reverb: false, echo: false, robot: false, gate: false, trem: false, crush: 0, stereo: false, noise: 0, pan: 0, bass: 0, presence: 0, lowmid: 0, air: 0, eqL: 0, eqM: 0, eqH: 0, hp: 20, lp: 20000 };
  const BUILTIN = [
    ['Absolute Max', { gain: 2500, dist: 200, loud: 400, clip: 400, drive2: 400, boostStage: 1500, outGain: 3000, ceil0: false, limiter: false, bass: 6, presence: 4, hp: 80 }],
    ['Max Loud', { gain: 2000, dist: 100, loud: 400, clip: 400, drive2: 200, boostStage: 600, outGain: 600, ceil0: false, limiter: false, bass: 6, presence: 4, hp: 80 }],
    ['High Gain', { gain: 1000, dist: 60, loud: 300, clip: 250, drive2: 100, boostStage: 0, ceil0: false, limiter: false, hp: 100 }],
    ['Loud and Clean', { ...RESET, gain: 40, dist: 10, loud: 150, clip: 60, ceil: true, hp: 100 }],
    ['Gated Loud', { gain: 800, dist: 60, loud: 300, clip: 200, drive2: 100, ceil0: false, limiter: false, gate: true, gateTh: -50, hp: 100 }],
    ['Radio', { ...RESET, gain: 20, dist: 15, loud: 120, hp: 300, lp: 3400, presence: 6, bass: -4 }],
    ['Robot', { ...RESET, gain: 30, robot: true, rmFreq: 60, rmMix: 100, loud: 120 }],
    ['Cave', { ...RESET, gain: 20, reverb: true, revDecay: 4.5, revMix: 60, echo: true, ecTime: 380, ecFb: 45, ecMix: 35 }],
    ['Flat reset', { ...RESET }]
  ];

  const pages = {
    Dashboard() {
      meterEl = el('i'); peakEl = el('u'); dbEl = el('div', { class: 'rd' }, 'Peak --');
      clipEl = el('span', { class: 'pill' }, 'CLIP'); gateEl = el('span', { class: 'pill g' }, 'GATE');
      histCv = el('canvas', { class: 'cv', width: 520, height: 56, style: 'height:56px' });
      specCv = el('canvas', { class: 'cv', width: 520, height: 84, style: 'height:84px' });
      heroNum = el('span', { class: 'hn' }, heroShown.toFixed(1));
      gainInfo = el('div', { class: 'hs' });
      cellsEl = el('div', { class: 'cells' });
      for (let c = 0; c < STAGES; c++) cellsEl.append(el('div', { class: 'cell' }, el('i', { style: 'transition-delay:' + (c * 18) + 'ms' })));
      const sv = document.createElementNS(NS, 'svg');
      sv.setAttribute('viewBox', '0 0 140 140'); sv.setAttribute('class', 'dial');
      const mk = cls => { const c = document.createElementNS(NS, 'circle'); c.setAttribute('cx', 70); c.setAttribute('cy', 70); c.setAttribute('r', 58); c.setAttribute('class', cls); c.setAttribute('transform', 'rotate(135 70 70)'); return c; };
      const tr = mk('dtrack'); tr.style.strokeDasharray = ARC + ' ' + CIRC;
      dialArc = mk('darc'); dialArc.style.strokeDasharray = '0 ' + CIRC;
      sv.append(tr, dialArc);
      const quick = el('div', { class: 'q' });
      [0, 60, 120, 500, 1000, 1500, 2000, 2500].forEach(v => quick.append(btn(v + ' dB', () => { S.gain = v; apply(); save(); render(); toast('Gain set to ' + v + ' dB'); })));
      quick.append(btn(S.turbo ? 'TURBO ON' : 'TURBO 1500 + 3000', toggleTurbo, 'pri'));
      heroEl = el('div', { class: 'hero' },
        el('div', { class: 'dialwrap' }, sv, el('div', { class: 'dc' }, heroNum, el('small', {}, 'dB'))),
        el('div', { class: 'hside' }, el('div', { class: 'ht' }, 'TOTAL GAIN'), gainInfo, cellsEl, quick));
      statEls = ['Peak', 'RMS', 'Clips', 'Session'].map(n => ({ n, b: el('b', {}, '--') }));
      const st = el('div', { class: 'stats' }, statEls.map(s => el('div', { class: 'stat' }, el('span', {}, s.n), s.b)));
      setTimeout(() => { updGain(); syncS(); }, 0);
      return el('div', {},
        chkCard(),
        grp('Gain', heroEl),
        st,
        cols(
          grp('Gain controls',
            slider('Input gain', 'inputGain', 1, 500, 0.1, v => v.toFixed(1) + 'x'),
            slider('Main gain', 'gain', -30, MAXDB, 0.5, v => v.toFixed(1) + ' dB', updGain),
            slider('Extra boost stage', 'boostStage', 0, MAXBOOST, 1, v => v + ' dB', updGain),
            slider('Output gain', 'outGain', -30, MAXOUT, 0.5, v => v.toFixed(1) + ' dB')),
          grp('Character',
            slider('Distortion', 'dist', 0, 400, 1, String),
            slider('Loudness boost', 'loud', 0, 400, 1, pct),
            slider('Clipper drive', 'clip', 0, 400, 1, String),
            slider('Clipper 2 drive', 'drive2', 0, 400, 1, String),
            slider('Encoder bitrate', 'bitrate', 8000, 510000, 1000, v => Math.round(v / 1000) + ' kbps'))),
        grp(null, el('h3', {}, 'Output level', clipEl, gateEl), el('div', { class: 'meter' }, meterEl, peakEl), dbEl, btn('Reset peak', () => { peakHold = -120; stats.peak = -120; stats.clips = 0; toast('Peak and clip counter reset'); })),
        cols(grp('Spectrum', specCv), grp('Level history', histCv)),
        grp('Quick switches', toggle('Safety limiter', 'limiter'), toggle('Max ceiling (0 dBFS)', 'ceil0'), toggle('Bypass all effects', 'bypass'), toggle('Mic mute', 'mute', applyMute)));
    },
    Effects() {
      rvCv = el('canvas', { class: 'cv', width: 300, height: 90, style: 'height:90px' });
      setTimeout(drawRV, 0);
      return el('div', {}, cols(
        grp('Reverb', toggle('Enable reverb', 'reverb', drawRV),
          slider('Size', 'revDecay', 0.2, 6, 0.1, v => v.toFixed(1) + ' s', drawRV),
          slider('Mix', 'revMix', 0, 100, 1, pct, drawRV), rvCv),
        grp('Stereo', toggle('Enable stereo width', 'stereo'),
          slider('Width', 'wmix', 0, 100, 1, pct),
          slider('Base delay', 'width', 1, 40, 1, v => v + ' ms'))),
        grp('Noise gate', toggle('Enable noise gate', 'gate'),
          slider('Threshold', 'gateTh', -90, -10, 1, v => v + ' dBFS'),
          slider('Release', 'gateRel', 20, 800, 10, v => v + ' ms'),
          note('The gate listens to the mic before the large gain is applied, so background noise stays silent between words even at very high gain.')),
        cols(
          grp('Tremolo', toggle('Enable tremolo', 'trem'),
            slider('Rate', 'tremRate', 0.5, 30, 0.5, v => v.toFixed(1) + ' Hz'),
            slider('Depth', 'tremDepth', 0, 100, 1, pct)),
          grp('Bit crusher and noise',
            slider('Bit reduction', 'crush', 0, 14, 1, v => v ? (16 - v) + ' bit' : 'off'),
            slider('Noise injection', 'noise', 0, 100, 1, String))));
    },
    'Voice FX'() {
      return el('div', {}, cols(
        grp('Echo', toggle('Enable echo', 'echo'),
          slider('Delay time', 'ecTime', 40, 1200, 10, v => v + ' ms'),
          slider('Feedback', 'ecFb', 0, 90, 1, pct),
          slider('Mix', 'ecMix', 0, 100, 1, pct)),
        grp('Robot voice', toggle('Enable ring modulator', 'robot'),
          slider('Frequency', 'rmFreq', 5, 600, 1, v => v + ' Hz'),
          slider('Mix', 'rmMix', 0, 100, 1, pct))),
        grp('Pitch shifter', toggle('Enable pitch shift', 'pitch'),
          slider('Shift', 'pitchSt', -12, 12, 0.5, v => (v > 0 ? '+' : '') + v.toFixed(1) + ' st'),
          slider('Mix', 'pitchMix', 0, 100, 1, pct),
          note('Uses a dual delay line shifter. It sounds cleanest with small shifts, around plus or minus 5 semitones.')),
        grp('Stereo position', slider('Pan', 'pan', -100, 100, 1, v => v === 0 ? 'center' : (v < 0 ? 'L ' + (-v) : 'R ' + v)),
          note('Pan only has an audible effect when your output is stereo (mono output is turned off in Controls).')));
    },
    Dynamics() {
      return el('div', {},
        grp('Compressor', slider('Attack', 'cAtk', 0, 100, 1, v => v + ' ms'), slider('Release', 'cRel', 10, 1000, 5, v => v + ' ms'), slider('Knee', 'cKnee', 0, 40, 1, v => v + ' dB')),
        grp('Safety cap', slider('Max total main gain', 'gainCap', 20, 4000, 10, v => v + ' dB', updGain), note('Caps main gain plus boost. Leave at 4000 dB for no cap.')),
        grp('Gain smoothing', slider('Smoothing time', 'smooth', 2, 500, 1, v => v + ' ms'), note('How fast gain changes glide. Low values react instantly, higher values avoid clicks and pops.')),
        grp('Limiter', toggle('Safety limiter', 'limiter'), toggle('Louder ceiling (-0.3 dB)', 'ceil'), toggle('Max ceiling (0 dBFS)', 'ceil0')),
        grp('How the gain works',
          note('Gain is applied in stages of up to 120 dB. Each stage is clamped to full scale before the next one, so every dB is really applied and nothing overflows: main gain up to 2500 dB, extra boost up to 1500 dB, output gain up to 3000 dB.'),
          note('Past roughly 60 to 80 dB the voice is already a squared-off wave, so the compressor, clippers and the ceiling decide how loud it actually sounds.')));
    },
    Equalizer() {
      eqCv = el('canvas', { class: 'cv', width: 400, height: 140, style: 'height:140px' });
      setTimeout(redrawEQ, 0);
      const f = v => v >= 1000 ? (v / 1000).toFixed(1) + ' kHz' : Math.round(v) + ' Hz';
      const d = v => v.toFixed(1) + ' dB';
      return el('div', {},
        grp('Response', toggle('Enable EQ', 'eqOn', redrawEQ), eqCv),
        cols(
          grp('Bands',
            slider('Bass shelf (90 Hz)', 'bass', -12, 24, 0.5, d, redrawEQ),
            slider('Low (200 Hz)', 'eqL', -12, 12, 0.5, d, redrawEQ),
            slider('Low-mid (500 Hz)', 'lowmid', -12, 12, 0.5, d, redrawEQ),
            slider('Mid (1.5 kHz)', 'eqM', -12, 12, 0.5, d, redrawEQ)),
          grp('Bands and filters',
            slider('Presence (3 kHz)', 'presence', -12, 12, 0.5, d, redrawEQ),
            slider('High (4 kHz)', 'eqH', -12, 12, 0.5, d, redrawEQ),
            slider('Air (9 kHz)', 'air', -12, 12, 0.5, d, redrawEQ),
            slider('High-pass', 'hp', 20, 2000, 1, f, redrawEQ),
            slider('Low-pass', 'lp', 1000, 20000, 50, f, redrawEQ))));
    },
    Media() {
      const file = el('input', { type: 'file', accept: 'audio/*', multiple: 'multiple', style: 'display:none' });
      listEl = el('div', { class: 'pl' });
      drawList();
      file.addEventListener('change', () => {
        [...file.files].forEach(f => list.push({ name: f.name, url: URL.createObjectURL(f) }));
        if (idx < 0 && list.length) loadTrack(0, false);
        drawList(); file.value = '';
      });
      const seek = el('input', { type: 'range', min: 0, max: 1000, step: 1 });
      const st = el('b', {}, '0:00 / 0:00');
      seek.value = 0; seek.style.setProperty('--p', '0%');
      let drag = false;
      seek.addEventListener('input', () => { drag = true; if (au.duration) au.currentTime = seek.value / 1000 * au.duration; seek.style.setProperty('--p', seek.value / 10 + '%'); });
      seek.addEventListener('change', () => { drag = false; });
      au.ontimeupdate = () => {
        if (!seek.isConnected) return;
        if (!drag && au.duration) { seek.value = au.currentTime / au.duration * 1000; seek.style.setProperty('--p', seek.value / 10 + '%'); }
        st.textContent = fmtT(au.currentTime) + ' / ' + fmtT(au.duration);
      };
      return el('div', {},
        grp('Playlist', file, listEl,
          btn('Add files', () => file.click(), 'pri'),
          btn('Previous', () => { if (list.length) loadTrack((idx - 1 + list.length) % list.length, true); drawList(); }),
          btn('Play', () => { ensureCtx(); ctx.resume(); au.play().catch(() => {}); }),
          btn('Pause', () => au.pause()),
          btn('Stop', () => { au.pause(); au.currentTime = 0; }),
          btn('Next', () => { if (list.length) loadTrack((idx + 1) % list.length, true); drawList(); }),
          btn('Clear list', () => { au.pause(); list = []; idx = -1; au.removeAttribute('src'); drawList(); }, 'dn')),
        grp('Playback', el('div', { class: 'sl' }, el('div', { class: 'h' }, el('span', {}, 'Position'), st), seek),
          slider('Volume', 'mp3Vol', 0, 4000, 5, pct),
          slider('Speed', 'mp3Rate', 0.5, 2, 0.05, v => v.toFixed(2) + 'x'),
          el('div', { class: 'q' }, el('span', { class: 'note' }, 'Sleep timer:'), [0, 15, 30, 60].map(m => btn(m ? m + ' min' : 'Off', () => setSleep(m)))),
          toggle('Repeat track', 'mp3Loop'), toggle('Shuffle', 'mp3Shuffle'),
          toggle('Send to voice chat (goes through effects)', 'mp3Mix')));
    },
    Presets() {
      const ta = el('textarea', { class: 'ta', placeholder: 'Exported settings appear here. Paste settings here to import.' });
      const slots = el('div');
      const sta = el('textarea', { class: 'ta', placeholder: 'Share code appears here. Paste a code and press Load.' });
      const exportAudio = () => { const o = {}; AUDIO_KEYS.forEach(k => o[k] = S[k]); return o; };
      for (let i = 1; i <= 6; i++) {
        const key = 'mx130v5_slot' + i;
        let has = false; try { has = !!localStorage.getItem(key); } catch (e) {}
        const lab = el('span', { class: has ? 'f' : '' }, 'Slot ' + i + (has ? '  saved' : '  empty'));
        slots.append(el('div', { class: 'slot' }, lab,
          btn('Save', () => { try { localStorage.setItem(key, JSON.stringify(exportAudio())); } catch (e) {} lab.textContent = 'Slot ' + i + '  saved'; lab.className = 'f'; toast('Slot ' + i + ' saved'); }),
          btn('Load', () => { try { const o = JSON.parse(localStorage.getItem(key) || 'null'); if (o) { Object.assign(S, o); save(); apply(); render(); toast('Slot ' + i + ' loaded'); } else toast('Slot ' + i + ' is empty'); } catch (e) {} }),
          btn('Clear', () => { try { localStorage.removeItem(key); } catch (e) {} lab.textContent = 'Slot ' + i + '  empty'; lab.className = ''; })));
      }
      const bi = el('div', { class: 'q' });
      BUILTIN.forEach(([n, o]) => bi.append(btn(n, () => { Object.assign(S, o); save(); apply(); render(); chk('preset'); toast(n + ' applied'); })));
      return el('div', {},
        grp('Built-in presets', bi),
        grp('My presets', slots),
        grp('Backup',
          btn('Export audio settings', () => { const t = JSON.stringify(exportAudio()); ta.value = t; try { navigator.clipboard.writeText(t).then(() => toast('Copied to clipboard'), () => toast('Exported below')); } catch (e) { toast('Exported below'); } }),
          btn('Import from box', () => { try { const o = JSON.parse(ta.value); AUDIO_KEYS.forEach(k => { if (k in o) S[k] = o[k]; }); save(); apply(); render(); toast('Settings imported'); } catch (e) { toast('Invalid settings text'); } }),
          ta),
        grp('A/B compare', btn('Save current as A', () => abSave('A')), btn('Save current as B', () => abSave('B')), btn('Swap A / B (Alt + B)', abSwap, 'pri'),
          note('Save two sound setups and flip between them instantly to hear the difference.')),
        grp('Share code',
          btn('Create share code', () => { const o = {}; AUDIO_KEYS.concat(LOOK_KEYS).forEach(k => o[k] = S[k]); const t = btoa(encodeURIComponent(JSON.stringify(o))); sta.value = t; try { navigator.clipboard.writeText(t).then(() => toast('Code copied'), () => toast('Code created below')); } catch (e) { toast('Code created below'); } }),
          btn('Load share code', () => { try { const o = JSON.parse(decodeURIComponent(atob(sta.value.trim()))); AUDIO_KEYS.concat(LOOK_KEYS).forEach(k => { if (k in o) S[k] = o[k]; }); save(); apply(); applyTheme(); render(); toast('Code loaded'); } catch (e) { toast('Invalid code'); } }),
          sta),
        grp('Maintenance',
          btn('Reset audio', () => { const keep = {}; LOOK_KEYS.forEach(k => keep[k] = S[k]); S = { ...DEF, ...keep }; save(); apply(); render(); toast('Audio reset'); }, 'dn'),
          btn('Re-apply bitrate', applyBitrateAll)));
    },
    Controls() {
      const keyBtn = el('button', { class: 'btn' }, 'Set key');
      keyBtn.addEventListener('click', () => {
        keyBtn.textContent = 'Press a key';
        const h = e => { e.preventDefault(); e.stopPropagation(); S.pttKey = e.code; save(); window.removeEventListener('keydown', h, true); render(); toast('Push-to-talk key: ' + e.code); };
        window.addEventListener('keydown', h, true);
      });
      return el('div', {}, cols(
        grp('Routing', toggle('Bypass all effects (send raw mic)', 'bypass'), toggle('Mic mute', 'mute', applyMute),
          toggle('Raw mic: disable browser filters (next join)', 'raw'), toggle('Hear myself (use headphones)', 'monitor'), toggle('Mono output', 'mono')),
        grp('Push to talk', toggle('Enable push to talk', 'ptt', applyMute),
          el('div', { class: 'row' }, el('span', {}, 'Key:'), el('span', { class: 'kbd' }, S.pttKey), keyBtn),
          note('When enabled, the processed mic is silent unless the key is held. The key works while the Discord tab is focused.'))),
        grp('Mic test', btn('Record 4 s and play back', () => micTest(4), 'pri'), btn('Record 8 s', () => micTest(8)),
          note('Records your processed mic and plays it back at 40% volume to protect your ears. Join a voice channel first so the mic is active.')),
        grp('Hotkeys',
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + M'), '  open or close panel'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + K'), '  bypass (panic: instantly raw mic)'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + G'), '  toggle noise gate'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + T'), '  TURBO (extra boost 1500 dB + output gain 3000 dB)'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + N'), '  mute or unmute mic'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + P'), '  command palette (search anything)'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + 1 to 8'), '  play soundboard pads'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + B'), '  swap A/B sound setups'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + H'), '  replay the welcome tour')));
    },
    Animation() {
      return el('div', {}, cols(
        grp('Master', toggle('Interface animations', 'anim', applyTheme),
          slider('Animation speed', 'animSpeed', 0.4, 2.5, 0.1, v => v.toFixed(1) + 'x', applyTheme),
          select('Panel open style', 'openAnim', [['flip', '3D flip (new)'], ['bounce', 'Bounce (new)'], ['zoomblur', 'Zoom blur (new)'], ['swing', 'Swing in (new)'], ['rise', 'Rise'], ['scale', 'Scale'], ['slide', 'Slide from left'], ['clip', 'Reveal'], ['fade', 'Fade']], applyTheme),
          select('Page transition', 'pageAnim', [['blur', 'Blur in (new)'], ['flip', 'Flip (new)'], ['bounce', 'Bounce (new)'], ['slide', 'Slide up'], ['fade', 'Fade'], ['zoom', 'Zoom'], ['none', 'None']], applyTheme),
          toggle('Staggered entrance', 'stagger')),
        grp('Ambient',
          toggle('Header light sweep', 'sweep', applyTheme), toggle('Animated logo bars', 'logoAnim', applyTheme),
          toggle('Scanline', 'scan', applyTheme), toggle('Moving grid', 'gridMove', applyTheme),
          toggle('Launcher pulse', 'fabPulse', applyTheme),
          toggle('Neon glowing border (new)', 'neon', applyTheme), toggle('Button shine sweep (new)', 'shine', applyTheme),
          toggle('Aurora hero glow (new)', 'aurora', applyTheme), toggle('Floating glow orbs (new)', 'orbs', applyTheme),
          toggle('Number glow (new)', 'glowNum', applyTheme), toggle('Shake at max gain (new)', 'shake', applyTheme),
          toggle('Spinning light border (v7)', 'spin', applyTheme), toggle('Floating particles (v7)', 'particles', applyTheme),
          slider('Particle count (v7)', 'partCount', 10, 120, 1, String, applyTheme),
          toggle('Title glitch (v7)', 'glitch', applyTheme), toggle('Gradient moving title (v7)', 'gtitle', applyTheme),
          toggle('Card spotlight follows cursor (v7)', 'spot', applyTheme))),
        grp('Interaction', toggle('Button ripple', 'ripple'), toggle('Hover motion', 'hoverFx', applyTheme), toggle('Number tween and value flicker', 'tween')),
        grp('Waveform background', toggle('Waveform reacts to your voice', 'wave', syncW),
          slider('Wave layers', 'waveLines', 1, 6, 1, String),
          slider('Wave speed', 'waveSpeed', 0.2, 3, 0.1, num(1)),
          slider('Wave height', 'waveAmp', 10, 100, 1, pct)));
    },
    Design() {
      const row = el('div');
      THEMES.forEach(([n, a, b]) => {
        const s = el('span', { class: 'sw' + (S.accent === a ? ' act' : ''), title: n, style: `background:linear-gradient(135deg,${a},${b})` });
        s.addEventListener('click', () => { S.accent = a; S.accent2 = b; S.rainbow = false; save(); applyTheme(); render(); });
        row.append(s);
      });
      return el('div', {},
        grp('Color presets', row),
        cols(
          grp('Colors', colorRow('Accent color', 'accent'), colorRow('Secondary color', 'accent2'), toggle('Rainbow mode (colors cycle)', 'rainbow', applyTheme)),
          grp('Surface', select('Layout', 'layout', [['dock', 'Bottom dock (new)'], ['side', 'Sidebar'], ['top', 'Top tabs']], applyTheme),
            select('Color scheme', 'scheme', [['midnight', 'Midnight'], ['amoled', 'AMOLED black'], ['slate', 'Slate'], ['plum', 'Plum'], ['forest', 'Forest'], ['ocean', 'Ocean'], ['crimson', 'Crimson']], applyTheme),
            toggle('Floating status HUD', 'hud'),
            select('Background style', 'bgStyle', [['mesh', 'Animated mesh (new)'], ['dots', 'Moving dots (new)'], ['glass', 'Glass'], ['solid', 'Solid'], ['gradient', 'Gradient'], ['grid', 'Blueprint grid']], applyTheme),
            select('Button style', 'btnStyle', [['grad', 'Gradient pill (new)'], ['pill', 'Pill'], ['classic', 'Classic']], applyTheme),
            slider('Glass blur', 'blur', 0, 30, 1, v => v + ' px', applyTheme),
            slider('Panel opacity', 'op', 40, 100, 1, pct, applyTheme),
            toggle('Show borders', 'borders', applyTheme))),
        cols(
          grp('Layout', slider('Panel width', 'pw', 520, 1000, 10, v => v + ' px', applyTheme),
            slider('Corner radius', 'radius', 0, 28, 1, v => v + ' px', applyTheme),
            slider('Density', 'dens', 0.7, 1.4, 0.05, v => v.toFixed(2) + 'x', applyTheme)),
          grp('Typography and launcher', select('Font', 'font', [['rounded', 'Rounded'], ['techno', 'Techno'], ['sans', 'Sans serif'], ['mono', 'Monospace'], ['serif', 'Serif']], applyTheme),
            slider('Font size', 'fs', 10, 18, 1, v => v + ' px', applyTheme),
            slider('Launcher size', 'fab', 36, 72, 1, v => v + ' px', applyTheme),
            toggle('Launcher on left side', 'fabLeft', applyTheme))),
        grp('Custom CSS (advanced)', (() => { const t = el('textarea', { class: 'ta', placeholder: '.card{border-radius:4px}' }); t.value = S.customCss || '';
          return el('div', {}, t, btn('Apply CSS', () => { S.customCss = t.value; save(); applyTheme(); toast('CSS applied'); }, 'pri'), btn('Clear', () => { S.customCss = ''; t.value = ''; save(); applyTheme(); })); })(),
          note('Styles apply inside the panel only. Use selectors like .card, .btn or .panel.')),
        grp(null, btn('Restore default look', () => { LOOK_KEYS.forEach(k => S[k] = DEF[k]); save(); applyTheme(); render(); toast('Default look restored'); }, 'dn')));
    },
    Soundboard() {
      padEls = [];
      const g = el('div', { class: 'pads' });
      pads.forEach((p, i) => {
        const f = el('input', { type: 'file', accept: 'audio/*', style: 'display:none' });
        f.addEventListener('change', () => { if (f.files[0]) loadPad(i, f.files[0]); });
        const b = el('button', { class: 'pad' + (p.buf ? ' has' : ''), onclick: () => (p.buf ? playPad(i) : f.click()) },
          el('small', {}, 'Alt + ' + (i + 1)), el('b', {}, p.buf ? p.name : 'Empty pad'), el('small', {}, p.buf ? fmtT(p.buf.duration) : 'tap to load a sound'));
        padEls[i] = b;
        g.append(el('div', { class: 'padw' }, b, f, el('button', { class: 'padx', title: 'Load or replace sound', onclick: e => { e.stopPropagation(); f.click(); } }, '+')));
      });
      return el('div', {},
        grp('Soundboard', g, btn('Stop all sounds', stopPads, 'dn')),
        grp('Soundboard mixer',
          slider('Soundboard volume', 'sbVol', 0, 4000, 5, pct),
          toggle('Send to voice chat (goes through effects)', 'sbMix'),
          note('Load up to 8 sounds, then trigger them with Alt + 1 to Alt + 8 while the Discord tab is focused. Sounds stay loaded until you reload the page. Loud pads also play on your own speakers, so check the volume first.')));
    },
    Visualizer() {
      vizCv = el('canvas', { class: 'cv', width: 760, height: 300, style: 'height:300px' });
      setTimeout(syncV, 0);
      return el('div', {},
        grp('Live visualizer', vizCv),
        cols(
          grp('Style', select('Mode', 'vizMode', [['circle', 'Radial'], ['bars', 'Bars'], ['mirror', 'Mirror bars'], ['scope', 'Oscilloscope']]),
            slider('Smoothing', 'vizSmooth', 0, 95, 1, pct), toggle('Peak caps (bars)', 'vizCaps')),
          grp('About', note('Shows the processed output that is sent to voice chat. It stays flat until you join a voice channel and speak.'))));
    },
    About() {
      return el('div', {},
        grp('Welcome tour', btn('Replay welcome tour', () => showTour(0), 'pri'), btn('Open command palette', openPal)),
        grp('Modexá 121',
          note('New in v10: Studio page with Auto-Calibrate, Smart Level, Auto-Duck, Voice Morph, Quick Slots and a session recorder, plus rank and XP (reach GOATED), a Pro look and a much deeper welcome tour.'),
          note('Processes your mic with the Web Audio API before Discord Web sends it: staged gain up to 2500 dB + 1500 dB boost, output gain up to 3000 dB, music volume up to 4000%, loudness (compressor, clippers, limiter), distortion, EQ, reverb, echo, robot voice, stereo width, noise gate, push to talk and a playlist player.'),
          note('Mic effects start after you join a voice channel. If you joined before the extension loaded, leave and rejoin.')),
        grp('Safety',
          note('Gain beyond about 60 to 80 dB lifts every bit of background noise to full scale. Use the noise gate, a high-pass filter around 80 to 120 Hz, (limiters are off by default, turn the limiter on if it gets too harsh). Use Alt + K for an instant return to the raw mic.'),
          note('Encoder bitrate sets the WebRTC maxBitrate for your audio. Discord may still limit it.'),
          note('Works on discord.com only. Client modifications may go against the Discord Terms of Service.')));
    }
  };

  const PAGES = ['Dashboard', 'Studio', 'Effects', 'Voice FX', 'Equalizer', 'Dynamics', 'Media', 'Soundboard', 'Visualizer', 'Presets', 'Controls', 'Animation', 'Design', 'About'];
  tabs.append(bar);
  PAGES.forEach(p => tabs.append(el('button', { 'data-p': p, onclick: () => { current = p; render(); } }, el('span', { class: 'ic' }, ICONS[p] || '•'), el('span', { class: 'tl' }, p))));

  function moveBar() {
    const b = tabs.querySelector('button.act');
    if (!b) return;
    bar.style.width = b.offsetWidth + 'px';
    bar.style.transform = 'translateX(' + b.offsetLeft + 'px)';
    if (S.layout === 'side') tabs.scrollTo({ top: Math.max(0, b.offsetTop - 80), behavior: S.anim ? 'smooth' : 'auto' });
    else tabs.scrollTo({ left: Math.max(0, b.offsetLeft - 60), behavior: S.anim ? 'smooth' : 'auto' });
  }

  function loadTrack(i, play) {
    if (i < 0 || i >= list.length) return;
    idx = i; ensureCtx(); au.src = list[i].url; trackName = list[i].name;
    if (play) { ctx.resume(); au.play().catch(() => {}); }
  }
  function drawList() {
    if (!listEl || !listEl.isConnected) return;
    listEl.replaceChildren();
    if (!list.length) { listEl.append(el('div', {}, 'No tracks loaded')); return; }
    list.forEach((t, i) => listEl.append(el('div', { class: i === idx ? 'cur' : '', onclick: () => { loadTrack(i, true); drawList(); } }, (i + 1) + '.  ' + t.name)));
  }
  au.onended = () => {
    if (!list.length) return;
    const n = S.mp3Shuffle ? Math.floor(Math.random() * list.length) : idx + 1;
    if (n < list.length) loadTrack(n, true);
    drawList();
  };

  function render() {
    meterEl = peakEl = dbEl = gainInfo = eqCv = rvCv = heroEl = cellsEl = heroNum = specCv = clipEl = gateEl = histCv = dialArc = statEls = listEl = null; vizCv = null; padEls = [];
    tabs.querySelectorAll('button').forEach(b => b.classList.toggle('act', b.dataset.p === current));
    const page = pages[current]();
    main.replaceChildren(page);
    let i = 0;
    page.querySelectorAll('.card,.stat').forEach(x => { x.classList.add('in'); x.style.setProperty('--i', S.stagger ? Math.min(i++, 14) : 0); });
    main.scrollTop = 0;
    moveBar();
  }

  const fab = el('button', { class: 'fab idle' });
  [0.55, 1, 0.8, 0.45].forEach(k => fab.append(el('i', { style: '--k:' + k })));

  const userStyle = el('style');
  const hudT = el('div'), hudB = el('i');
  const hud = el('div', { class: 'hud' }, hudT, hudB);

  function applyTheme() {
    const s = wrap.style;
    s.setProperty('--accent', S.accent); s.setProperty('--accent2', S.accent2);
    s.setProperty('--blur', S.blur); s.setProperty('--radius', S.radius + 'px');
    s.setProperty('--fs', S.fs + 'px'); s.setProperty('--opp', S.op + '%');
    s.setProperty('--ff', FONTS[S.font] || FONTS.sans); s.setProperty('--pw', S.pw + 'px');
    s.setProperty('--dens', S.dens); s.setProperty('--fab', S.fab + 'px');
    s.setProperty('--spd', (1 / Math.max(0.25, S.animSpeed)).toFixed(3));
    const sc = SCHEMES[S.scheme] || SCHEMES.midnight;
    s.setProperty('--bg', sc[0]); s.setProperty('--surf', sc[1]); s.setProperty('--surf2', sc[2]);
    s.setProperty('--line', S.borders ? sc[3] : 'transparent');
    wrap.classList.toggle('noanim', !S.anim);
    const pc = panel.classList;
    ['glass', 'solid', 'gradient', 'grid', 'mesh', 'dots'].forEach(b => pc.toggle('bg-' + b, S.bgStyle === b));
    ['rise', 'scale', 'slide', 'clip', 'fade', 'flip', 'bounce', 'zoomblur', 'swing'].forEach(o => pc.toggle('oa-' + o, S.openAnim === o));
    ['classic', 'grad', 'pill'].forEach(b => pc.toggle('bs-' + b, S.btnStyle === b));
    pc.toggle('lay-side', S.layout === 'side'); pc.toggle('lay-dock', S.layout === 'dock');
    userStyle.textContent = S.customCss || '';
    pc.toggle('v10', !!S.pro);
    ['neon','shine','aurora','shake','orbs','glowNum','spin','glitch','gtitle','spot'].forEach(k => pc.toggle('x-' + k, !!S[k]));
    pc.toggle('nosweep', !S.sweep); pc.toggle('noscan', !S.scan); pc.toggle('nogrid', !S.gridMove);
    pc.toggle('nologo', !S.logoAnim); pc.toggle('nohover', !S.hoverFx);
    main.className = 'pg-' + S.pageAnim;
    fab.classList.toggle('nopulse', !S.fabPulse);
    fab.style.left = S.fabLeft ? '12px' : 'auto';
    fab.style.right = S.fabLeft ? 'auto' : '12px';
    hud.style.left = S.fabLeft ? '12px' : 'auto'; hud.style.right = S.fabLeft ? 'auto' : '12px';
    moveBar();
    syncP();
  }
  setInterval(() => {
    if (!S.rainbow) return;
    hue = (hue + 3) % 360;
    wrap.style.setProperty('--accent', `hsl(${hue} 90% 62%)`);
    wrap.style.setProperty('--accent2', `hsl(${(hue + 60) % 360} 80% 50%)`);
  }, 90);

  /* ---- graphs ---- */
  function redrawEQ() {
    if (!eqCv || !eqCv.isConnected) return;
    if (!nodes) ensureCtx();
    const cv = eqCv, c = cv.getContext('2d'), w = cv.width, h = cv.height, N = 120;
    const fr = new Float32Array(N), mag = new Float32Array(N), ph = new Float32Array(N), tot = new Float32Array(N).fill(1);
    for (let i = 0; i < N; i++) fr[i] = 20 * Math.pow(1000, i / (N - 1));
    [nodes.hp, nodes.eqB, nodes.eqL, nodes.eqLM, nodes.eqM, nodes.eqP, nodes.eqH, nodes.eqA, nodes.lp].forEach(f => { f.getFrequencyResponse(fr, mag, ph); for (let i = 0; i < N; i++) tot[i] *= mag[i]; });
    c.clearRect(0, 0, w, h);
    c.strokeStyle = '#232a3a'; c.lineWidth = 1;
    for (let k = 1; k < 4; k++) { c.beginPath(); c.moveTo(0, h * k / 4); c.lineTo(w, h * k / 4); c.stroke(); }
    c.strokeStyle = curAccent(); c.lineWidth = 2; c.beginPath();
    for (let i = 0; i < N; i++) {
      const db = Math.max(-18, Math.min(18, 20 * Math.log10(tot[i] || 1e-6)));
      const x = i / (N - 1) * w, y = h / 2 - db / 18 * (h / 2 - 4);
      i ? c.lineTo(x, y) : c.moveTo(x, y);
    }
    c.stroke();
  }
  function drawRV() {
    if (!rvCv || !rvCv.isConnected) return;
    const c = rvCv.getContext('2d'), w = rvCv.width, h = rvCv.height, k = S.revDecay / 6, m = S.revMix / 100;
    c.clearRect(0, 0, w, h);
    c.strokeStyle = S.reverb ? curAccent() : '#555b6e'; c.lineWidth = 1;
    for (let i = 1; i <= 7; i++) {
      const f = i / 7 * (0.25 + 0.75 * k), rw = w * f, rh = h * f;
      c.globalAlpha = (S.reverb ? 0.3 + 0.7 * m : 0.4) * (1 - i / 9);
      c.beginPath(); c.arc(w / 2, h / 2, Math.min(rw, rh) / 1.4, 0, 6.283); c.stroke();
    }
    c.globalAlpha = 1;
  }

  /* ---- live spectrum ---- */
  let sRun = false, specData = null;
  const specBars = new Float32Array(56), specPeaks = new Float32Array(56);
  function syncS() { if (panelOpen && specCv && specCv.isConnected && !sRun) { sRun = true; requestAnimationFrame(specFrame); } }
  function specFrame() {
    if (!(panelOpen && specCv && specCv.isConnected)) { sRun = false; return; }
    const c = specCv.getContext('2d'), w = specCv.width, h = specCv.height, B = specBars.length, bw = w / B, col = curAccent();
    c.clearRect(0, 0, w, h);
    let len = 0;
    if (nodes) { specData = specData || new Uint8Array(nodes.an.frequencyBinCount); nodes.an.getByteFrequencyData(specData); len = specData.length; }
    for (let i = 0; i < B; i++) {
      let v = 0;
      if (len) {
        const lo = Math.floor(Math.pow(i / B, 2.2) * len * 0.9), hi = Math.max(lo + 1, Math.floor(Math.pow((i + 1) / B, 2.2) * len * 0.9));
        for (let k = lo; k <= hi && k < len; k++) v = Math.max(v, specData[k]);
        v /= 255;
      }
      specBars[i] = v > specBars[i] ? v : specBars[i] * 0.88 + v * 0.12;
      specPeaks[i] = Math.max(specBars[i], specPeaks[i] - 0.006);
      const bh = Math.max(2, specBars[i] * (h - 6)), x = i * bw + 1;
      c.globalAlpha = 0.3; c.fillStyle = col; c.fillRect(x, h - bh, bw - 2, bh);
      c.globalAlpha = 0.95; c.fillRect(x, h - bh, bw - 2, 2);
      c.globalAlpha = 0.6; c.fillRect(x, h - Math.max(2, specPeaks[i] * (h - 6)) - 3, bw - 2, 1.5);
    }
    c.globalAlpha = 1;
    requestAnimationFrame(specFrame);
  }

  /* ---- floating particles (v7) ---- */
  function syncP() { if (panelOpen && S.particles && S.anim && !pRunning) { pRunning = true; requestAnimationFrame(pframe); } }
  function pframe() {
    const c = pcanvas.getContext('2d');
    if (!(panelOpen && S.particles && S.anim)) { pRunning = false; c.clearRect(0, 0, pcanvas.width, pcanvas.height); return; }
    const r = pcanvas.getBoundingClientRect();
    if (pcanvas.width !== Math.round(r.width) || pcanvas.height !== Math.round(r.height)) { pcanvas.width = Math.round(r.width); pcanvas.height = Math.round(r.height); }
    const w = pcanvas.width, h = pcanvas.height, col = curAccent(), n = Math.max(5, Math.min(150, S.partCount | 0));
    while (parts.length < n) parts.push({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * 2 + 0.7, vy: Math.random() * 0.5 + 0.15, vx: (Math.random() - 0.5) * 0.3, ph: Math.random() * 6.28 });
    parts.length = n;
    c.clearRect(0, 0, w, h);
    const sp = S.animSpeed * (1 + level * 3);
    c.fillStyle = col; c.strokeStyle = col; c.lineWidth = 0.6;
    for (const p of parts) {
      p.ph += 0.02; p.y -= p.vy * sp; p.x += p.vx * sp + Math.sin(p.ph) * 0.25;
      if (p.y < -5) { p.y = h + 5; p.x = Math.random() * w; }
      if (p.x < 0) p.x = w; if (p.x > w) p.x = 0;
      c.globalAlpha = 0.25 + 0.5 * Math.abs(Math.sin(p.ph));
      c.beginPath(); c.arc(p.x, p.y, p.r * (1 + level), 0, 6.283); c.fill();
    }
    for (let i = 0; i < parts.length; i++) for (let j = i + 1; j < parts.length; j++) {
      const dx = parts[i].x - parts[j].x, dy = parts[i].y - parts[j].y, d = dx * dx + dy * dy;
      if (d < 5600) { c.globalAlpha = (1 - d / 5600) * 0.22; c.beginPath(); c.moveTo(parts[i].x, parts[i].y); c.lineTo(parts[j].x, parts[j].y); c.stroke(); }
    }
    c.globalAlpha = 1;
    requestAnimationFrame(pframe);
  }

  /* ---- waveform background ---- */
  let wRunning = false;
  function syncW() { if (panelOpen && S.wave && !wRunning) { wRunning = true; requestAnimationFrame(frame); } }
  function frame(ts) {
    const c = canvas.getContext('2d');
    if (!(panelOpen && S.wave)) { wRunning = false; c.clearRect(0, 0, canvas.width, canvas.height); return; }
    const r = canvas.getBoundingClientRect();
    if (canvas.width !== Math.round(r.width) || canvas.height !== Math.round(r.height)) { canvas.width = Math.round(r.width); canvas.height = Math.round(r.height); }
    const w = canvas.width, h = canvas.height, col = curAccent(), t = ts / 1000 * S.waveSpeed;
    const amp = h * 0.045 * (S.waveAmp / 50), lv = 0.25 + level * 1.8;
    c.clearRect(0, 0, w, h);
    c.strokeStyle = col; c.lineWidth = 1.5;
    for (let k = 0; k < S.waveLines; k++) {
      c.globalAlpha = Math.max(0.05, 0.3 - k * 0.04);
      c.beginPath();
      const base = h * (0.84 - k * 0.06);
      for (let x = 0; x <= w; x += 5) {
        const y = base
          + Math.sin(x * 0.011 * (1 + k * 0.3) + t * (1 + k * 0.35) + k * 1.7) * amp * lv
          + Math.sin(x * 0.027 - t * 1.4 + k) * amp * 0.4 * lv;
        x ? c.lineTo(x, y) : c.moveTo(x, y);
      }
      c.stroke();
      c.lineTo(w, h); c.lineTo(0, h); c.closePath(); c.globalAlpha = Math.max(0.02, 0.07 - k * 0.01); c.fillStyle = col; c.fill();
    }
    c.globalAlpha = 1;
    requestAnimationFrame(frame);
  }

  /* ---- header, open / close / drag ---- */
  const closeBtn = el('button', { class: 'x', onclick: () => setOpen(false), title: 'Close' });
  const dot = el('i', { class: 'dot' });
  const stTxt = el('span', {}, 'Waiting for mic');
  const muteBtn = el('button', { class: 'mb', title: 'Mute or unmute mic (Alt + N)', onclick: () => { S.mute = !S.mute; save(); applyMute(); if (panelOpen) render(); } }, 'MIC LIVE');
  onMuteChange = () => {
    const m = S.mute || (S.ptt && !pttDown);
    muteBtn.textContent = S.mute ? 'MUTED' : (S.ptt ? (pttDown ? 'PTT OPEN' : 'PTT IDLE') : 'MIC LIVE');
    muteBtn.classList.toggle('muted', m);
  };
  const logo = el('div', { class: 'logo' }, el('i'), el('i'), el('i'), el('i'));
  const hd = el('div', { class: 'hd' }, logo, el('span', { class: 'ti', 'data-t': 'MODEXÁ' }, 'MODEXÁ', el('span', { class: 'ver' }, '121')), el('div', { class: 'st' }, dot, stTxt), muteBtn, closeBtn);

  function setOpen(v) {
    if (v === panelOpen) return;
    panelOpen = v;
    if (v) {
      panel.classList.remove('out'); panel.classList.add('on');
      if (!panel.style.left) {
        panel.style.left = Math.max(4, (innerWidth - panel.offsetWidth) / 2) + 'px';
        panel.style.top = Math.max(4, innerHeight * 0.07) + 'px';
      }
      render(); syncW(); syncS(); syncP(); onMuteChange();
    } else {
      panel.classList.add('out');
      setTimeout(() => { if (!panelOpen) panel.classList.remove('on', 'out'); }, 220);
    }
  }
  fab.addEventListener('click', () => setOpen(!panelOpen));
  hd.addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    const r = panel.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
    hd.setPointerCapture(e.pointerId);
    const mv = ev => {
      panel.style.left = Math.max(0, Math.min(innerWidth - 60, ev.clientX - dx)) + 'px';
      panel.style.top = Math.max(0, Math.min(innerHeight - 40, ev.clientY - dy)) + 'px';
    };
    const up = () => { hd.removeEventListener('pointermove', mv); hd.removeEventListener('pointerup', up); };
    hd.addEventListener('pointermove', mv); hd.addEventListener('pointerup', up);
  });
  function toggleTurbo() { S.turbo = !S.turbo; if (nodes) apply(); save(); updGain(); if (panelOpen) render(); toast(S.turbo ? 'TURBO ON: boost 1500 dB + output 3000 dB' : 'Turbo off'); }
  panel.addEventListener('keydown', e => e.stopPropagation());
  window.addEventListener('keydown', e => {
    if (!e.altKey) return;
    if (e.code === 'KeyM') { e.preventDefault(); setOpen(!panelOpen); }
    else if (e.code === 'KeyK') { e.preventDefault(); S.bypass = !S.bypass; apply(); save(); if (panelOpen) render(); toast(S.bypass ? 'Bypass on' : 'Bypass off'); }
    else if (e.code === 'KeyT') { e.preventDefault(); toggleTurbo(); }
    else if (e.code === 'KeyG') { e.preventDefault(); S.gate = !S.gate; apply(); save(); if (panelOpen) render(); }
    else if (e.code === 'KeyN') { e.preventDefault(); S.mute = !S.mute; save(); applyMute(); if (panelOpen) render(); }
    else if (e.code === 'KeyP') { e.preventDefault(); openPal(); }
    else if (e.code === 'KeyH') { e.preventDefault(); showTour(0); }
    else if (e.code === 'KeyB') { e.preventDefault(); abSwap(); }
    else if (/^Digit[1-8]$/.test(e.code) && !e.shiftKey) { e.preventDefault(); playPad(+e.code.slice(5) - 1); }
  }, true);
  window.addEventListener('keydown', e => { if (S.ptt && e.code === S.pttKey && !e.repeat) { pttDown = true; applyMute(); } }, true);
  window.addEventListener('keyup', e => { if (S.ptt && e.code === S.pttKey) { pttDown = false; applyMute(); } }, true);
  window.addEventListener('blur', () => { if (pttDown) { pttDown = false; applyMute(); } });

  panel.addEventListener('pointerdown', e => {
    const b = e.target.closest && e.target.closest('.btn,.tabs button');
    if (!b || !S.anim || !S.ripple) return;
    const r = b.getBoundingClientRect(), sp = el('span', { class: 'rip' });
    sp.style.left = (e.clientX - r.left) + 'px'; sp.style.top = (e.clientY - r.top) + 'px';
    b.append(sp); setTimeout(() => sp.remove(), 650);
  });
  panel.addEventListener('pointermove', e => {
    if (!S.spot) return;
    const cd = e.target.closest && e.target.closest('.card');
    if (!cd) return;
    const r = cd.getBoundingClientRect();
    cd.style.setProperty('--mx', (e.clientX - r.left) + 'px'); cd.style.setProperty('--my', (e.clientY - r.top) + 'px');
  });
  const fx = el('div', { class: 'fx' });
  panel.append(fx, el('div', { class: 'orb o1' }), el('div', { class: 'orb o2' }), canvas, pcanvas, hd, el('div', { class: 'body' }, tabs, main), toastBox, el('div', { class: 'ring' }), el('div', { class: 'ring2' }));
  wrap.append(panel, fab, hud);
  root.append(el('style', {}, CSS + CSS10), userStyle, wrap);
  applyTheme();

  /* ---- soundboard ---- */
  function flashPad(i) { const b = padEls[i]; if (!b || !b.isConnected) return; b.classList.remove('hit'); void b.offsetWidth; b.classList.add('hit'); }
  function playPad(i) {
    const p = pads[i];
    if (!p || !p.buf) { toast('Pad ' + (i + 1) + ' is empty'); return; }
    ensureCtx(); ctx.resume();
    try { p.src && p.src.stop(); } catch (e) {}
    const src = ctx.createBufferSource(); src.buffer = p.buf; src.connect(nodes.sbG); src.start();
    p.src = src; src.onended = () => { if (p.src === src) p.src = null; };
    flashPad(i);
  }
  function stopPads() { pads.forEach(p => { try { p.src && p.src.stop(); } catch (e) {} p.src = null; }); }
  async function loadPad(i, file) {
    ensureCtx();
    try {
      const b = await ctx.decodeAudioData(await file.arrayBuffer());
      pads[i].buf = b; pads[i].name = file.name.replace(/\.[^.]+$/, '');
      chk('pad'); toast('Pad ' + (i + 1) + ' loaded');
      if (panelOpen && current === 'Soundboard') render();
    } catch (e) { toast('Could not read that audio file'); }
  }

  /* ---- mic test recorder ---- */
  function micTest(sec) {
    if (!micSrc || !nodes) { toast('Join a voice channel first so the mic is active'); return; }
    if (rec) { toast('Already recording'); return; }
    try {
      const chunks = [], r = new MediaRecorder(nodes.dest.stream);
      rec = r;
      r.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
      r.onstop = () => {
        rec = null;
        const a = new Audio(URL.createObjectURL(new Blob(chunks, { type: r.mimeType || 'audio/webm' })));
        a.volume = 0.4; toast('Playing your test'); a.play().catch(() => {});
      };
      r.start(); chk('test'); toast('Recording ' + sec + ' s, speak now');
      setTimeout(() => { try { r.stop(); } catch (e) {} }, sec * 1000);
    } catch (e) { rec = null; toast('Recording is not supported here'); }
  }

  /* ---- visualizer ---- */
  function syncV() { if (panelOpen && vizCv && vizCv.isConnected && !vRun) { vRun = true; requestAnimationFrame(vizFrame); } }
  function vizFrame(ts) {
    if (!(panelOpen && vizCv && vizCv.isConnected)) { vRun = false; return; }
    const c = vizCv.getContext('2d'), w = vizCv.width, h = vizCv.height, B = vBars.length;
    const c1 = curAccent(), c2 = (wrap.style.getPropertyValue('--accent2') || S.accent2).trim();
    c.clearRect(0, 0, w, h);
    let len = 0;
    if (nodes) {
      vData = vData || new Uint8Array(nodes.an.frequencyBinCount); nodes.an.getByteFrequencyData(vData);
      vTime = vTime || new Uint8Array(nodes.an.fftSize); nodes.an.getByteTimeDomainData(vTime); len = vData.length;
    }
    const sm = S.vizSmooth / 100;
    for (let i = 0; i < B; i++) {
      let v = 0;
      if (len) {
        const lo = Math.floor(Math.pow(i / B, 2) * len * 0.8), hi = Math.max(lo + 1, Math.floor(Math.pow((i + 1) / B, 2) * len * 0.8));
        for (let k = lo; k <= hi && k < len; k++) v = Math.max(v, vData[k]);
        v /= 255;
      }
      vBars[i] = v > vBars[i] ? v : vBars[i] * sm + v * (1 - sm);
      vCaps[i] = Math.max(vBars[i], vCaps[i] - 0.008);
    }
    const gr = c.createLinearGradient(0, h, 0, 0); gr.addColorStop(0, c2); gr.addColorStop(1, c1);
    c.fillStyle = gr; c.strokeStyle = gr;
    const bw = w / B;
    if (S.vizMode === 'bars') {
      for (let i = 0; i < B; i++) {
        const bh = Math.max(2, vBars[i] * (h - 8));
        c.fillRect(i * bw + 1, h - bh, bw - 2, bh);
        if (S.vizCaps) { c.fillStyle = c1; c.fillRect(i * bw + 1, h - Math.max(2, vCaps[i] * (h - 8)) - 4, bw - 2, 2); c.fillStyle = gr; }
      }
    } else if (S.vizMode === 'mirror') {
      for (let i = 0; i < B; i++) {
        const bh = Math.max(2, vBars[i] * (h / 2 - 6));
        c.fillRect(i * bw + 1, h / 2 - bh, bw - 2, bh); c.globalAlpha = 0.45; c.fillRect(i * bw + 1, h / 2, bw - 2, bh); c.globalAlpha = 1;
      }
    } else if (S.vizMode === 'circle') {
      const cx = w / 2, cy = h / 2, R = Math.min(w, h) * (0.2 + level * 0.05), rot = ts / 6000;
      c.lineWidth = 3; c.lineCap = 'round';
      for (let i = 0; i < B; i++) {
        const a = i / B * 6.2832 + rot, l = 4 + vBars[i] * Math.min(w, h) * 0.3;
        c.strokeStyle = i % 2 ? c1 : c2;
        c.beginPath(); c.moveTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R); c.lineTo(cx + Math.cos(a) * (R + l), cy + Math.sin(a) * (R + l)); c.stroke();
      }
      c.globalAlpha = 0.35; c.strokeStyle = c1; c.lineWidth = 1.5; c.beginPath(); c.arc(cx, cy, R - 6, 0, 6.2832); c.stroke(); c.globalAlpha = 1;
    } else {
      c.lineWidth = 2; c.strokeStyle = gr; c.beginPath();
      const n = vTime ? vTime.length : 0;
      for (let i = 0; i < 256; i++) { const v = n ? (vTime[Math.floor(i / 256 * n)] - 128) / 128 : 0, x = i / 255 * w, y = h / 2 + v * (h / 2 - 8); i ? c.lineTo(x, y) : c.moveTo(x, y); }
      c.stroke();
    }
    requestAnimationFrame(vizFrame);
  }

  /* ---- command palette ---- */
  function closePal() { if (palEl) palEl.remove(); palEl = null; }
  function cmdList() {
    const a = [];
    PAGES.forEach(p => a.push(['Go to ' + p, () => { current = p; if (!panelOpen) setOpen(true); render(); }]));
    a.push(['Toggle TURBO', toggleTurbo]);
    a.push(['Toggle bypass (raw mic)', () => { S.bypass = !S.bypass; apply(); save(); if (panelOpen) render(); toast(S.bypass ? 'Bypass on' : 'Bypass off'); }]);
    a.push(['Toggle noise gate', () => { S.gate = !S.gate; apply(); save(); if (panelOpen) render(); toast(S.gate ? 'Gate on' : 'Gate off'); }]);
    a.push(['Toggle mic mute', () => { S.mute = !S.mute; save(); applyMute(); if (panelOpen) render(); }]);
    a.push(['Toggle limiter', () => { S.limiter = !S.limiter; apply(); save(); if (panelOpen) render(); toast(S.limiter ? 'Limiter on' : 'Limiter off'); }]);
    a.push(['Toggle status HUD', () => { S.hud = !S.hud; save(); if (panelOpen) render(); }]);
    a.push(['Stop all soundboard sounds', stopPads]);
    a.push(['Mic test (4 s)', () => micTest(4)]);
    a.push(['Replay welcome tour', () => showTour(0)]);
    BUILTIN.forEach(([n, o]) => a.push(['Preset: ' + n, () => { Object.assign(S, o); save(); apply(); chk('preset'); if (panelOpen) render(); toast(n + ' applied'); }]));
    THEMES.forEach(([n, x, y]) => a.push(['Theme: ' + n, () => { S.accent = x; S.accent2 = y; S.rainbow = false; save(); applyTheme(); if (panelOpen) render(); }]));
    Object.keys(SCHEMES).forEach(k => a.push(['Scheme: ' + k, () => { S.scheme = k; save(); applyTheme(); if (panelOpen) render(); }]));
    a.push(['Layout: bottom dock', () => { S.layout = 'dock'; save(); applyTheme(); }], ['Pitch shifter: toggle', () => { S.pitch = !S.pitch; apply(); save(); if (panelOpen) render(); }], ['A/B: swap setups', abSwap], ['Layout: sidebar', () => { S.layout = 'side'; save(); applyTheme(); }], ['Layout: top tabs', () => { S.layout = 'top'; save(); applyTheme(); }]);
    a.push(['Auto-Calibrate mic (opens Studio)', () => { current = 'Studio'; if (!panelOpen) setOpen(true); render(); }],
      ['Toggle Smart Level (auto gain)', () => { S.agc = !S.agc; agcCur = null; if (S.agc) chk('agc'); save(); if (panelOpen) render(); toast(S.agc ? 'Smart Level on' : 'Smart Level off'); }],
      ['Toggle Auto-Duck music', () => { S.duck = !S.duck; if (S.duck) chk('duck'); save(); if (panelOpen) render(); toast(S.duck ? 'Auto-Duck on' : 'Auto-Duck off'); }],
      ['Recorder: start or stop', recToggle],
      ['Pro look: toggle', () => { S.pro = !S.pro; save(); applyTheme(); if (panelOpen) render(); }]);
    MORPH.forEach(m => a.push(['Voice Morph: ' + m[0], () => morph(m[0])]));
    [1, 2, 3, 4].forEach(i => a.push(['Quick Slot ' + i + ': load', () => slotLoad(i)], ['Quick Slot ' + i + ': save', () => { slotSave(i); if (panelOpen) render(); }]));
    return a;
  }
  function openPal() {
    if (palEl) { closePal(); return; }
    if (!panelOpen) setOpen(true);
    chk('pal');
    palEl = el('div', { class: 'pal' });
    const box = el('div', { class: 'palc' }), inp = el('input', { placeholder: 'Type a command, page, preset or theme...' }), lst = el('div', { class: 'pall' });
    const all = cmdList(); let sel = 0, items = [];
    const run = i => { const x = items[i]; closePal(); if (x) x[1](); };
    const draw = () => {
      const q = inp.value.toLowerCase().trim();
      items = all.filter(x => x[0].toLowerCase().includes(q)).slice(0, 40);
      sel = Math.min(sel, Math.max(0, items.length - 1));
      lst.replaceChildren(...items.map((x, i) => el('div', { class: i === sel ? 'sel' : '', onclick: () => run(i) }, x[0])));
      const cur = lst.querySelector('.sel'); if (cur) cur.scrollIntoView({ block: 'nearest' });
    };
    inp.addEventListener('input', () => { sel = 0; draw(); });
    inp.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { sel = Math.min(items.length - 1, sel + 1); draw(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); }
      else if (e.key === 'Enter') run(sel);
      else if (e.key === 'Escape') closePal();
    });
    palEl.addEventListener('pointerdown', e => { if (e.target === palEl) closePal(); });
    box.append(inp, lst); palEl.append(box); panel.append(palEl); draw();
    setTimeout(() => inp.focus(), 40);
  }

  /* ================= v10: rank, studio, calibrate, smart level, duck, morph, slots, recorder ================= */
  const XPV = { mic: 50, test: 30, preset: 20, pad: 25, pal: 15, cal: 80, rec: 40, morph: 25, slot: 25, agc: 30, duck: 30, tour: 100, look: 15, safety: 15 };
  const XPN = { mic: 'Mic connected', test: 'Mic test done', preset: 'Preset applied', pad: 'Soundboard pad loaded', pal: 'Command palette opened', cal: 'Auto-Calibrate done', rec: 'First recording', morph: 'Voice Morph tried', slot: 'Quick Slot saved', agc: 'Smart Level on', duck: 'Auto-Duck on', tour: 'Tour finished', look: 'Look chosen', safety: 'Safety set' };
  const RANKS = [[0, 'Rookie'], [100, 'Rising'], [220, 'Pro'], [340, 'Elite'], [430, 'Legend'], [500, 'GOATED']];
  const xpGet = () => { try { return JSON.parse(localStorage.getItem('mx130_xp10') || '{}'); } catch (e) { return {}; } };
  const xpSave = o => { try { localStorage.setItem('mx130_xp10', JSON.stringify(o)); } catch (e) {} };
  const xpTotal = () => { const o = xpGet(); return Object.keys(XPV).reduce((a, k) => a + (o[k] ? XPV[k] : 0), 0); };
  const rankOf = xp => { let i = 0; RANKS.forEach((r, j) => { if (xp >= r[0]) i = j; }); return { i, name: RANKS[i][1] }; };
  const rankEl = el('span', { class: 'rk', title: 'Your Modexá rank. Click for the Dashboard.' }, 'ROOKIE');
  rankEl.addEventListener('pointerdown', e => e.stopPropagation());
  rankEl.addEventListener('click', () => { current = 'Dashboard'; render(); });
  hd.insertBefore(rankEl, hd.querySelector('.st'));
  function updateRank() {
    const xp = xpTotal(), r = rankOf(xp);
    rankEl.textContent = r.name.toUpperCase();
    rankEl.style.display = S.rankHud ? '' : 'none';
    rankEl.classList.toggle('gt', xp >= 500);
    panel.classList.toggle('goated', xp >= 500);
  }
  function goated() {
    confetti(); setTimeout(confetti, 600); setTimeout(confetti, 1300);
    toast('MODEXÁ GOATED. You unlocked every rank.');
  }
  function xpAward(k) {
    const v = XPV[k]; if (!v) return;
    const o = xpGet(); if (o[k]) return;
    const before = rankOf(xpTotal()).i;
    o[k] = 1; xpSave(o);
    toast('+' + v + ' XP  ' + XPN[k]);
    updateRank();
    const after = rankOf(xpTotal()).i;
    if (after > before) { if (RANKS[after][1] === 'GOATED') goated(); else toast('Rank up: ' + RANKS[after][1]); }
  }
  function rankCard() {
    const xp = xpTotal(), r = rankOf(xp), nx = RANKS[r.i + 1];
    const f = nx ? (xp - RANKS[r.i][0]) / (nx[0] - RANKS[r.i][0]) : 1;
    return grp('Rank',
      el('div', { class: 'rkc' }, el('div', { class: 'rkn' }, r.name), el('div', { class: 'rks' }, xp + ' XP' + (nx ? '   next: ' + nx[1] + ' at ' + nx[0] : '   max rank'))),
      el('div', { class: 'prog' }, el('i', { style: 'width:' + (f * 100) + '%' })),
      note(xp >= 500 ? 'Modexá is GOATED. You tried everything.' : 'Earn XP by trying features: calibrate, record, morph, save slots and more. 500 XP makes you GOATED.'));
  }
  const _dash = pages.Dashboard;
  pages.Dashboard = function () { const p = _dash(); p.prepend(rankCard()); return p; };

  /* ---- helpers ---- */
  const pctl = (a, p) => { const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
  const lvl = (A, b) => {
    A.getFloatTimeDomainData(b);
    let s = 0, p = 0; for (const v of b) { s += v * v; p = Math.max(p, Math.abs(v)); }
    const r = Math.sqrt(s / b.length);
    return [r > 0 ? 20 * Math.log10(r) : -120, p > 0 ? 20 * Math.log10(p) : -120];
  };
  const clampN = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---- Auto-Calibrate: 3 s quiet + 4 s talking, reads the mic before the gain stages ---- */
  let calBusy = false;
  function runCal(setMsg, setProg) {
    return new Promise((res, rej) => {
      if (!nodes || !micSrc) { rej(new Error('nomic')); return; }
      if (calBusy) { rej(new Error('busy')); return; }
      calBusy = true;
      const A = nodes.anG, b = new Float32Array(A.fftSize), data = [[], []], t0 = performance.now();
      setMsg('Stay quiet for 3 seconds...');
      const iv = setInterval(() => {
        const t = performance.now() - t0;
        setProg(Math.min(1, t / 7000));
        const ph = t < 3000 ? 0 : 1;
        if (ph === 1) setMsg('Now talk normally...');
        if (t > 400) data[ph].push(lvl(A, b));
        if (t >= 7000) {
          clearInterval(iv); calBusy = false;
          const fR = pctl(data[0].map(x => x[0]), 0.9), fP = pctl(data[0].map(x => x[1]), 0.95);
          const talk = data[1].filter(x => x[0] > fR + 6);
          if (talk.length < 8) { res({ ok: false, floor: fR }); return; }
          const sR = pctl(talk.map(x => x[0]), 0.7), sP = pctl(talk.map(x => x[1]), 0.95);
          const snr = sR - fR;
          res({
            ok: true, floor: fR, speech: sR, snr,
            rating: snr >= 35 ? 'Excellent' : snr >= 25 ? 'Good' : snr >= 15 ? 'Fair' : 'Noisy',
            gateTh: Math.round(clampN(Math.min(fP + 5, sP - 10), -75, -20)),
            hp: fR > -55 ? 120 : 80,
            gain: Math.round(clampN(-20 - sR, 0, 80))
          });
        }
      }, 60);
    });
  }
  function calWidget(onDone) {
    const msg = el('div', { class: 'obp' }, 'Stay quiet for 3 seconds, then talk normally for 4 seconds.');
    const bar = el('i'), prog = el('div', { class: 'prog' }, bar), out = el('div', { class: 'cal' });
    const go = btn('Start calibration', () => {
      out.replaceChildren();
      if (!micSrc) { msg.textContent = 'Mic is not active yet. Join a voice channel in Discord first, then press start.'; return; }
      go.disabled = true; bar.style.width = '0%';
      runCal(m => { msg.textContent = m; }, p => { bar.style.width = (p * 100) + '%'; }).then(r => {
        go.disabled = false;
        if (!r.ok) { msg.textContent = 'I could not hear you clearly. Speak a bit louder or closer to the mic and try again.'; return; }
        msg.textContent = 'Done. Room is ' + r.rating.toLowerCase() + '. Choose what to apply.';
        const row = (a, v) => el('div', { class: 'calr' }, el('span', {}, a), el('b', {}, v));
        out.replaceChildren(
          row('Noise floor', r.floor.toFixed(1) + ' dBFS'), row('Your voice', r.speech.toFixed(1) + ' dBFS'),
          row('Signal to noise', r.snr.toFixed(1) + ' dB  (' + r.rating + ')'),
          row('Suggested gate / filter / gain', r.gateTh + ' dB  /  ' + r.hp + ' Hz  /  ' + r.gain + ' dB'),
          btn('Apply gate + filter', () => { Object.assign(S, { gate: true, gateTh: r.gateTh, hp: r.hp }); apply(); save(); chk('cal'); toast('Gate and filter applied'); onDone && onDone(r); }, 'pri'),
          btn('Apply all (with gain)', () => { Object.assign(S, { gate: true, gateTh: r.gateTh, hp: r.hp, gain: r.gain }); apply(); save(); chk('cal'); toast('Calibration applied'); onDone && onDone(r); }));
      }).catch(() => { go.disabled = false; msg.textContent = 'Calibration could not start. Make sure you are in a voice channel.'; });
    }, 'pri');
    return el('div', {}, msg, prog, go, out);
  }

  /* ---- Smart Level (auto gain) ---- */
  let agcCur = null, agcSaveT = 0, agcBuf = null;
  setInterval(() => {
    if (!nodes || !S.agc || !micSrc || S.bypass) return;
    agcBuf = agcBuf || new Float32Array(nodes.anG.fftSize);
    const d = lvl(nodes.anG, agcBuf)[0];
    if (d < (S.gate ? S.gateTh - 4 : -52)) return;
    if (agcCur === null) agcCur = Number(S.gain) || 0;
    const want = clampN((Number(S.agcTarget) || -20) - d, 0, Number(S.agcMax) || 60);
    agcCur += (want - agcCur) * 0.06;
    if (Math.abs(agcCur - S.gain) >= 0.4) {
      S.gain = Math.round(agcCur * 10) / 10; apply();
      if (panelOpen) updGain();
      const now = Date.now(); if (now - agcSaveT > 2000) { agcSaveT = now; save(); }
    }
  }, 120);

  /* ---- Auto-Duck: lowers music while you speak ---- */
  let duckNode = null, duckGain = 1, duckHold = 0, duckBuf = null;
  setInterval(() => {
    if (!nodes) return;
    if (!duckNode) {
      if (!S.duck) return;
      duckNode = ctx.createGain();
      try { nodes.mp3Src.disconnect(nodes.mp3Vol); } catch (e) {}
      nodes.mp3Src.connect(duckNode); duckNode.connect(nodes.mp3Vol);
    }
    let target = 1;
    if (S.duck && micSrc && !(S.mute || (S.ptt && !pttDown))) {
      duckBuf = duckBuf || new Float32Array(nodes.anG.fftSize);
      const pk = lvl(nodes.anG, duckBuf)[1], now = performance.now();
      if (pk > (S.gate ? S.gateTh : -45)) duckHold = now;
      if (now - duckHold < 450) target = Math.pow(10, -(Number(S.duckDepth) || 18) / 20);
    }
    duckGain += (target - duckGain) * (target < duckGain ? 0.4 : 0.12);
    duckNode.gain.setTargetAtTime(duckGain, ctx.currentTime, 0.02);
  }, 40);

  /* ---- Voice Morph (one tap pitch looks) ---- */
  const MORPH = [
    ['Chipmunk', { pitch: true, pitchSt: 7, pitchMix: 100, robot: false }],
    ['Kid', { pitch: true, pitchSt: 4, pitchMix: 100, robot: false }],
    ['Deep', { pitch: true, pitchSt: -4, pitchMix: 100, robot: false }],
    ['Giant', { pitch: true, pitchSt: -8, pitchMix: 100, robot: false, reverb: true, revDecay: 2.8, revMix: 25 }],
    ['Alien', { pitch: true, pitchSt: 5, pitchMix: 100, robot: true, rmFreq: 40, rmMix: 60 }],
    ['Demon', { pitch: true, pitchSt: -10, pitchMix: 100, robot: true, rmFreq: 30, rmMix: 40 }],
    ['Normal voice', { pitch: false, pitchSt: 0, robot: false, reverb: false }]
  ];
  function morph(name) {
    const m = MORPH.find(x => x[0] === name); if (!m) return;
    Object.assign(S, m[1]); apply(); save(); chk('morph');
    if (panelOpen) render(); toast('Voice: ' + name);
  }

  /* ---- Quick Slots (Alt + Shift + 1 to 4 loads) ---- */
  const slotGet = () => { try { return JSON.parse(localStorage.getItem('mx130_slots') || '{}'); } catch (e) { return {}; } };
  function slotSave(i) { const all = slotGet(), o = {}; AUDIO_KEYS.forEach(k => o[k] = S[k]); all[i] = o; try { localStorage.setItem('mx130_slots', JSON.stringify(all)); } catch (e) {} chk('slot'); toast('Saved to slot ' + i); }
  function slotLoad(i) {
    const o = slotGet()[i]; if (!o) { toast('Slot ' + i + ' is empty. Save one in Studio.'); return; }
    Object.assign(S, o); apply(); save(); if (panelOpen) render(); toast('Loaded slot ' + i);
  }

  /* ---- Session recorder: saves what Discord hears (mic + music + soundboard) ---- */
  let recS = null, recChunks = [], recT0 = 0, recBtn = null, recLbl = null;
  function updRec() {
    if (recBtn && recBtn.isConnected) recBtn.textContent = recS ? 'Stop and save' : 'Start recording';
    if (recLbl && recLbl.isConnected) { const s = recS ? Math.floor((Date.now() - recT0) / 1000) : 0; recLbl.textContent = recS ? 'REC ' + fmtT(s) : 'Not recording'; }
  }
  function recToggle() {
    if (recS) { try { recS.stop(); } catch (e) {} return; }
    if (!nodes || !micSrc) { toast('Join a voice channel first so the mic is active'); return; }
    try {
      const r = new MediaRecorder(nodes.dest.stream); recChunks = [];
      r.ondataavailable = e => { if (e.data && e.data.size) recChunks.push(e.data); };
      r.onstop = () => {
        recS = null;
        const blob = new Blob(recChunks, { type: r.mimeType || 'audio/webm' });
        if (blob.size) {
          const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
          a.download = 'modexa-' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.webm';
          document.documentElement.appendChild(a); a.click();
          setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
          toast('Clip saved (' + Math.round(blob.size / 1024) + ' KB)');
        }
        updRec();
      };
      r.start(1000); recS = r; recT0 = Date.now(); chk('rec'); toast('Recording started'); updRec();
    } catch (e) { recS = null; toast('Recording is not supported here'); }
  }
  setInterval(() => { if (recS) updRec(); }, 500);

  /* ---- Studio page ---- */
  pages.Studio = function () {
    recBtn = btn('Start recording', recToggle, 'pri'); recLbl = el('div', { class: 'rd' }, 'Not recording'); updRec();
    const slots = [1, 2, 3, 4].map(i => el('div', { class: 'row' },
      el('span', {}, 'Slot ' + i + (slotGet()[i] ? '   saved' : '   empty')),
      btn('Save', () => { slotSave(i); render(); }), btn('Load', () => slotLoad(i))));
    return el('div', {},
      grp('Auto-Calibrate', note('Measures your room noise and your voice, then suggests the gate, high-pass filter and gain for you.'), calWidget()),
      grp('Smart Level', note('Keeps your voice at a steady level automatically, whether you lean in or sit back.'),
        toggle('Smart Level (auto gain)', 'agc', () => { agcCur = null; if (S.agc) chk('agc'); }),
        slider('Target level', 'agcTarget', -40, -6, 1, v => v + ' dBFS'),
        slider('Max auto gain', 'agcMax', 0, 120, 1, v => v + ' dB'),
        note('Alt + L toggles it. It only adjusts while you are speaking.')),
      grp('Auto-Duck music', note('Your music or media gets quieter while you talk and comes back when you stop.'),
        toggle('Duck music while I speak', 'duck', () => { if (S.duck) chk('duck'); }),
        slider('Duck depth', 'duckDepth', 6, 40, 1, v => '-' + v + ' dB')),
      grp('Voice Morph', note('One tap voice looks using the pitch shifter. Fine tune on the Voice FX page.'),
        el('div', { class: 'q' }, MORPH.map(m => btn(m[0], () => morph(m[0]))))),
      grp('Quick Slots', note('Save your whole sound setup. Alt + Shift + 1 to 4 loads a slot from anywhere.'), ...slots),
      grp('Session recorder', note('Records exactly what Discord hears (mic, music and soundboard) and saves a clip. Alt + R starts or stops.'), recLbl, recBtn),
      grp('Look', toggle('Pro look (glow, glass cards)', 'pro', applyTheme), toggle('Rank badge in header', 'rankHud', updateRank),
        el('div', { class: 'q' },
          btn('Goated look', () => { Object.assign(S, { scheme: 'void', accent: '#ffd54a', accent2: '#ff6a00', rainbow: false, pro: true }); save(); applyTheme(); render(); chk('look'); }),
          btn('Aurora look', () => { Object.assign(S, { scheme: 'aurora', accent: '#7cffcb', accent2: '#74a9ff', rainbow: false, pro: true }); save(); applyTheme(); render(); chk('look'); }),
          btn('Neon Noir look', () => { Object.assign(S, { scheme: 'obsidian', accent: '#ff2e97', accent2: '#7b2fff', rainbow: false, pro: true }); save(); applyTheme(); render(); chk('look'); }))));
  };

  /* ---- keyboard: Alt+R record, Alt+L smart level, Alt+Shift+1..4 slots ---- */
  window.addEventListener('keydown', e => {
    if (!e.altKey) return;
    if (e.code === 'KeyR') { e.preventDefault(); recToggle(); }
    else if (e.code === 'KeyL') { e.preventDefault(); S.agc = !S.agc; agcCur = null; if (S.agc) chk('agc'); save(); if (panelOpen) render(); toast(S.agc ? 'Smart Level on' : 'Smart Level off'); }
    else if (e.shiftKey && /^Digit[1-4]$/.test(e.code)) { e.preventDefault(); e.stopPropagation(); slotLoad(+e.code.slice(5)); }
  }, true);

  /* ---- onboarding: tour state ---- */
  const obDone = () => { try { return localStorage.getItem('mx130_ob10') === '1'; } catch (e) { return false; } };
  function closeTour() { if (obEl) obEl.remove(); obEl = null; try { localStorage.setItem('mx130_ob10', '1'); localStorage.setItem('mx130_ob9', '1'); } catch (e) {} }
  const CHK = [['mic', 'Join a voice channel'], ['cal', 'Run Auto-Calibrate (Studio)'], ['test', 'Run a mic test (Controls)'], ['preset', 'Apply a preset'], ['morph', 'Try a Voice Morph (Studio)'], ['rec', 'Record a clip (Studio)'], ['slot', 'Save a Quick Slot (Studio)'], ['pal', 'Open the command palette (Alt + P)']];
  const chkGet = () => { try { return JSON.parse(localStorage.getItem('mx130_chk') || '{}'); } catch (e) { return {}; } };
  const chkSave = o => { try { localStorage.setItem('mx130_chk', JSON.stringify(o)); } catch (e) {} };
  const chk = k => { const o = chkGet(); if (!o[k]) { o[k] = 1; chkSave(o); } xpAward(k); };
  function chkCard() {
    if (micSrc) chk('mic');
    const o = chkGet();
    if (o.hide) return null;
    const done = CHK.filter(x => o[x[0]]).length;
    const cells = el('div', { class: 'cells' }, CHK.map(x => el('div', { class: 'cell' }, el('i', { style: 'transform:scaleX(' + (o[x[0]] ? 1 : 0) + ')' }))));
    return grp('Getting started  ' + done + '/' + CHK.length, cells,
      CHK.map(x => el('div', { class: 'note' }, (o[x[0]] ? '✓  ' : '○  ') + x[1])),
      done === CHK.length ? note('All done. Nice work.') : null,
      btn('Hide checklist', () => { const q = chkGet(); q.hide = 1; chkSave(q); render(); }),
      btn('Replay tour', () => showTour(0)));
  }
  updateRank();

  /* ---- A/B compare, sleep timer, confetti ---- */
  const ab = { A: null, B: null, cur: null };
  function abSave(k) { const o = {}; AUDIO_KEYS.forEach(x => o[x] = S[x]); ab[k] = o; ab.cur = k; toast('Saved as ' + k); }
  function abSwap() {
    if (!ab.A || !ab.B) { toast('Save both A and B first (Presets page)'); return; }
    const to = ab.cur === 'A' ? 'B' : 'A';
    Object.assign(S, ab[to]); ab.cur = to; save(); apply(); if (panelOpen) render(); toast('Now using ' + to);
  }
  let sleepT = null;
  function setSleep(min) {
    clearTimeout(sleepT); sleepT = null;
    if (!min) { toast('Sleep timer off'); return; }
    sleepT = setTimeout(() => { au.pause(); toast('Sleep timer: music paused'); }, min * 60000);
    toast('Music will pause in ' + min + ' min');
  }
  function confetti() {
    const cols = [curAccent(), (wrap.style.getPropertyValue('--accent2') || S.accent2).trim(), '#ffffff'];
    for (let i = 0; i < 44; i++) {
      const d = el('span', { class: 'cf' });
      d.style.left = (Math.random() * 100) + '%'; d.style.background = cols[i % 3];
      d.style.setProperty('--dx', (Math.random() * 180 - 90) + 'px'); d.style.animationDelay = (Math.random() * 0.4) + 's';
      panel.append(d); setTimeout(() => d.remove(), 2600);
    }
  }

  /* ---- onboarding tour (v10: goal, mic check, auto-calibrate, look, power-ups, safety, score) ---- */
  function showTour(start) {
    if (obEl) obEl.remove();
    if (!panelOpen) setOpen(true);
    const N = 8; let step = start || 0, goal = -1;
    const returning = (() => { try { return localStorage.getItem('mx130_ob9') === '1'; } catch (e) { return false; } })();
    obEl = el('div', { class: 'ob' }); panel.append(obEl);
    const gated = (BUILTIN.find(b => b[0] === 'Gated Loud') || [0, {}])[1];
    const GOALS = [
      ['Gaming and calls', 'Clear, loud voice with the noise gate on.', { ...RESET, gain: 40, dist: 10, loud: 150, clip: 60, ceil: true, hp: 100, gate: true, gateTh: -50, limiter: true }],
      ['Streaming and music', 'Wide stereo, gentle boost, music goes to voice chat.', { ...RESET, gain: 25, loud: 120, hp: 60, stereo: true, wmix: 60, mp3Mix: true, gate: false }],
      ['Voice changer', 'Deeper voice with a touch of loudness. Morph more in Studio.', { ...RESET, gain: 25, loud: 120, hp: 80, pitch: true, pitchSt: -4, pitchMix: 100 }],
      ['Maximum power', 'Very high gain with the gate to keep silence clean.', { ...gated }],
      ['Just exploring', 'Do not change anything yet.', null]
    ];
    const h = t => el('div', { class: 'obh' }, t), pp = t => el('div', { class: 'obp' }, t);
    const score = () => {
      const o = chkGet(), cap = Number(S.gainCap) || 4000;
      const parts = [
        [micSrc ? 25 : 0, 'Join a voice channel so the mic is active (+25)'],
        [o.cal ? 25 : 0, 'Run Auto-Calibrate in Studio (+25)'],
        [goal >= 0 ? 10 : 0, 'Pick a goal (+10)'],
        [(S.gate || S.agc) ? 15 : 0, 'Turn on the noise gate or Smart Level (+15)'],
        [cap < 4000 ? 10 : 0, 'Set a gain cap (+10)'],
        [(S.agc || S.duck) ? 5 : 0, 'Try Smart Level or Auto-Duck (+5)'],
        [10, '']
      ];
      return { sc: parts.reduce((a, p) => a + p[0], 0), todo: parts.filter(p => !p[0] && p[1]).map(p => p[1]) };
    };
    const draw = () => {
      const c = el('div', { class: 'obc' });
      if (step === 0) {
        c.append(h(returning ? 'Welcome back. Modexá 121 is here' : 'Welcome to Modexá 121'),
          pp('This tool sits between your microphone and Discord Web. It shapes your voice with gain, loudness, EQ, pitch and effects before anyone hears it.'),
          el('div', { class: 'obk' }, ['Auto-Calibrate', 'Smart Level', 'Auto-Duck', 'Voice Morph', 'Recorder', 'Quick Slots', 'Rank and XP', 'New Pro look'].map(t => el('span', { class: 'chip' }, t))),
          pp('The tour takes about two minutes: pick a goal, check your mic, calibrate, choose a look, switch on power-ups and set a safety limit. You earn XP for each step. Reach 500 XP and you become GOATED.'));
      } else if (step === 1) {
        c.append(h('What do you want to do?'), pp('Pick the closest goal. It sets a sensible starting sound that you can change later.'));
        GOALS.forEach((g, i) => c.append(el('button', { class: 'opt' + (goal === i ? ' sel' : ''), onclick: () => { goal = i; if (g[2]) { Object.assign(S, g[2]); save(); apply(); chk('preset'); } draw(); } }, el('b', {}, g[0]), el('small', {}, g[1]))));
      } else if (step === 2) {
        const lv = el('i'), meter = el('div', { class: 'meter' }, lv), stat = el('div', { class: 'obp' });
        let tb = null;
        const iv = setInterval(() => {
          if (!obEl || !meter.isConnected) { clearInterval(iv); return; }
          if (nodes) {
            tb = tb || new Float32Array(nodes.an.fftSize); nodes.an.getFloatTimeDomainData(tb);
            let q = 0; for (const v of tb) q += v * v;
            const r = Math.sqrt(q / tb.length), d = r > 0 ? 20 * Math.log10(r) : -120;
            lv.style.width = (100 - Math.max(0, Math.min(1, (d + 60) / 60)) * 100) + '%';
          }
          stat.textContent = micSrc ? 'Mic is active. Say something and watch the bar move.' : 'Waiting for mic. Open a voice channel in Discord and join it, then this turns active.';
        }, 100);
        c.append(h('Mic check'), pp('Your mic only starts after you join a voice channel.'), meter, stat,
          btn('Record a 4 s test', () => micTest(4)), pp('The test plays back at 40% volume to protect your ears.'));
      } else if (step === 3) {
        c.append(h('Auto-Calibrate'), pp('Modexá listens to your room for 3 seconds, then to your voice for 4 seconds. It then suggests the best gate, filter and gain. You can skip this and do it later in Studio.'), calWidget());
      } else if (step === 4) {
        const sw = el('div', { class: 'obk' });
        THEMES.slice(0, 12).concat(THEMES.slice(-4)).forEach(([n, a, b]) => { const x = el('span', { class: 'sw' + (S.accent === a ? ' act' : ''), title: n, style: 'background:linear-gradient(135deg,' + a + ',' + b + ')' }); x.addEventListener('click', () => { S.accent = a; S.accent2 = b; S.rainbow = false; save(); applyTheme(); draw(); }); sw.append(x); });
        const LAY = { dock: 'Bottom dock', side: 'Sidebar', top: 'Top tabs' };
        const lay = el('div', { class: 'obk' }, Object.keys(LAY).map(k => el('button', { class: 'btn' + (S.layout === k ? ' pri' : ''), onclick: () => { S.layout = k; save(); applyTheme(); draw(); } }, LAY[k])));
        const sch = el('div', { class: 'obk' }, Object.keys(SCHEMES).map(k => el('button', { class: 'btn' + (S.scheme === k ? ' pri' : ''), onclick: () => { S.scheme = k; save(); applyTheme(); draw(); } }, k)));
        const quick = el('div', { class: 'obk' },
          btn('Goated look', () => { Object.assign(S, { scheme: 'void', accent: '#ffd54a', accent2: '#ff6a00', rainbow: false, pro: true }); save(); applyTheme(); draw(); }, 'pri'),
          btn('Aurora look', () => { Object.assign(S, { scheme: 'aurora', accent: '#7cffcb', accent2: '#74a9ff', rainbow: false, pro: true }); save(); applyTheme(); draw(); }),
          btn('Neon Noir look', () => { Object.assign(S, { scheme: 'obsidian', accent: '#ff2e97', accent2: '#7b2fff', rainbow: false, pro: true }); save(); applyTheme(); draw(); }));
        c.append(h('Pick your look'), pp('One tap looks first, or build your own. Everything applies instantly.'), quick, sw, lay, sch, toggle('Pro look (glow, glass cards)', 'pro', applyTheme));
      } else if (step === 5) {
        c.append(h('Power-ups'), pp('Switch on what you want. All of them live in Studio and the command palette too.'),
          toggle('Smart Level: keeps your voice at a steady level', 'agc', () => { agcCur = null; if (S.agc) chk('agc'); }),
          toggle('Auto-Duck: music gets quieter while you talk', 'duck', () => { if (S.duck) chk('duck'); }),
          toggle('Noise gate: silence between words', 'gate'),
          toggle('Floating status HUD', 'hud'),
          toggle('Rank badge in header', 'rankHud', updateRank));
      } else if (step === 6) {
        const caps = [[4000, 'No cap', 'Use the full range of gain.'], [1000, 'Cap at 1000 dB', 'Keeps total main gain at or below 1000 dB.'], [200, 'Cap at 200 dB', 'Safer for everyday use.']];
        c.append(h('Safety'), pp('Very high gain also lifts background noise to full scale. A cap and the gate help. Alt + K always returns your raw mic.'));
        caps.forEach(([v, t, d]) => c.append(el('button', { class: 'opt' + ((Number(S.gainCap) || 4000) === v ? ' sel' : ''), onclick: () => { S.gainCap = v; apply(); save(); draw(); } }, el('b', {}, t), el('small', {}, d))));
      } else {
        const r = score();
        c.append(h('You are ready'),
          el('div', { class: 'score' }, el('b', {}, String(r.sc)), el('span', { class: 'rks' }, '/ 100  setup score')),
          el('div', { class: 'prog' }, el('i', { style: 'width:' + r.sc + '%' })),
          r.todo.length ? pp('To raise your score: ' + r.todo.slice(0, 3).join('  |  ')) : pp('Perfect setup. Nothing left to improve.'),
          pp('Handy shortcuts:'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + M'), '  open or close this panel'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + P'), '  command palette, search anything'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + K'), '  panic: raw mic'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + R'), '  record or stop a clip'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + L'), '  Smart Level on or off'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + B'), '  swap A/B sound setups'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + Shift + 1 to 4'), '  load Quick Slots'),
          el('div', { class: 'note' }, el('span', { class: 'kbd' }, 'Alt + 1 to 8'), '  soundboard pads'));
      }
      c.append(el('div', { class: 'obdots' }, Array.from({ length: N }, (_, i) => el('i', { class: i === step ? 'on' : '' }))));
      c.append(el('div', { class: 'obf' }, btn('Skip', closeTour),
        el('div', {}, step ? btn('Back', () => { step--; draw(); }) : null, btn(step === N - 1 ? 'Finish' : 'Next', () => {
          if (step === 4) chk('look');
          if (step === 6) chk('safety');
          if (step === N - 1) { closeTour(); chk('tour'); confetti(); updateRank(); render(); }
          else { step++; draw(); }
        }, 'pri'))));
      obEl.replaceChildren(c);
    };
    draw();
  }
  document.addEventListener('DOMContentLoaded', () => { updateRank(); if (!obDone()) setTimeout(() => { if (!obDone() && !obEl) showTour(0); }, 1400); });

  /* ---- noise gate (reads the mic before the gain stages) ---- */
  let gBuf = null, gHold = 0;
  setInterval(() => {
    if (!nodes || !S.gate) return;
    gBuf = gBuf || new Float32Array(nodes.anG.fftSize);
    nodes.anG.getFloatTimeDomainData(gBuf);
    let pk = 0; for (const v of gBuf) pk = Math.max(pk, Math.abs(v));
    const db = pk > 0 ? 20 * Math.log10(pk) : -120, now = performance.now();
    if (db > S.gateTh) gHold = now;
    const open = now - gHold < S.gateRel;
    if (open !== gateOpen) {
      gateOpen = open;
      const t = ctx.currentTime;
      nodes.gate.gain.cancelScheduledValues(t);
      nodes.gate.gain.setTargetAtTime(open ? 1 : 0, t, open ? 0.004 : 0.03);
    }
  }, 15);

  /* ---- level tick (meter, launcher, status, stats) ---- */
  setInterval(() => {
    let pk = 0, rms = 0;
    if (nodes) {
      const a = nodes.an; buf = buf || new Float32Array(a.fftSize);
      a.getFloatTimeDomainData(buf);
      let s = 0; for (const v of buf) { s += v * v; pk = Math.max(pk, Math.abs(v)); }
      rms = Math.sqrt(s / buf.length);
    }
    const db = pk > 0 ? 20 * Math.log10(pk) : -120;
    const rdb = rms > 0 ? 20 * Math.log10(rms) : -120;
    const lv = Math.max(0, Math.min(1, (db + 60) / 60));
    level = level * 0.6 + lv * 0.4;
    fab.style.setProperty('--lvl', level.toFixed(3));
    fab.classList.toggle('idle', level < 0.03);
    hud.style.setProperty('--lvl', level.toFixed(3));
    const showHud = !!S.hud && !panelOpen;
    hud.classList.toggle('on', showHud);
    if (showHud) hudT.innerHTML = '<em>' + (S.mute || (S.ptt && !pttDown) ? 'MUTED' : (S.bypass ? 'RAW MIC' : 'FX ON')) + '</em> ' + Math.round(totalDb()) + ' dB<br>OUT ' + Math.round(effOut()) + ' dB' + (S.turbo ? ' TURBO' : '');
    stats.peak = Math.max(stats.peak, db);
    const isClip = db > -0.6;
    if (isClip && !stats.wasClip) stats.clips++;
    stats.wasClip = isClip;
    hist.copyWithin(0, 1); hist[hist.length - 1] = db;
    if (!panelOpen) return;
    if (histCv && histCv.isConnected) {
      const c = histCv.getContext('2d'), w = histCv.width, h = histCv.height;
      c.clearRect(0, 0, w, h);
      c.fillStyle = curAccent(); c.globalAlpha = 0.28; c.beginPath(); c.moveTo(0, h);
      for (let i = 0; i < hist.length; i++) c.lineTo(i / (hist.length - 1) * w, h - Math.max(0, Math.min(1, (hist[i] + 60) / 60)) * (h - 4));
      c.lineTo(w, h); c.closePath(); c.fill();
      c.globalAlpha = 1; c.strokeStyle = curAccent(); c.lineWidth = 1.5; c.beginPath();
      for (let i = 0; i < hist.length; i++) { const y = h - Math.max(0, Math.min(1, (hist[i] + 60) / 60)) * (h - 4); i ? c.lineTo(i / (hist.length - 1) * w, y) : c.moveTo(0, y); }
      c.stroke();
    }
    if (gateEl && gateEl.isConnected) gateEl.classList.toggle('on', S.gate && gateOpen);
    const live = !!micSrc;
    dot.classList.toggle('live', live);
    stTxt.textContent = live ? 'Mic processing active' : 'Waiting for mic';
    if (clipEl && clipEl.isConnected) { const now = performance.now(); if (isClip) clipT = now; clipEl.classList.toggle('on', now - clipT < 700); }
    if (statEls && statEls[0].b.isConnected) {
      const f = v => v > -119 ? v.toFixed(1) + ' dB' : '--';
      const secs = Math.floor((Date.now() - stats.t0) / 1000);
      statEls[0].b.textContent = f(stats.peak);
      statEls[1].b.textContent = f(rdb);
      statEls[2].b.textContent = String(stats.clips);
      statEls[3].b.textContent = Math.floor(secs / 60) + ':' + String(secs % 60).padStart(2, '0');
    }
    if (meterEl && meterEl.isConnected) {
      meterEl.style.width = (100 - Math.max(0, Math.min(1, (rdb + 60) / 60)) * 100) + '%';
      peakHold = Math.max(db, peakHold - 0.3);
      if (peakEl) peakEl.style.left = 'calc(' + (Math.max(0, Math.min(1, (peakHold + 60) / 60)) * 100) + '% - 3px)';
      if (dbEl && dbEl.isConnected) dbEl.textContent = 'Peak ' + db.toFixed(1) + ' dBFS    hold ' + peakHold.toFixed(1) + ' dBFS';
    }
  }, 60);

  const mount = () => { if (!host.isConnected && document.documentElement) document.documentElement.appendChild(host); };
  mount();
  document.addEventListener('DOMContentLoaded', mount);
  setInterval(mount, 3000);
})();
